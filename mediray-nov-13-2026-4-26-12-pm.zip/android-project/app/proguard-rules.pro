-keep class org.webrtc.** { *; }
-keep class io.getstream.webrtc.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}

package com.mediray.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class LocalRepository(context: Context) {
    private val prefs = context.getSharedPreferences("mediray_prefs_v3", Context.MODE_PRIVATE)
    val ephemeralDir: File = File(context.filesDir, "ephemeral").apply { mkdirs() }

    companion object {
        const val TTL_MILLIS = 30L * 60L * 1000L
        private const val KEY_PHONE = "user_phone"
        private const val KEY_NAME = "user_name"
        private const val KEY_AVATAR = "user_avatar"
        private const val KEY_FRIENDS = "friends_json"
        private const val KEY_REQUESTS = "requests_json"
        private const val KEY_MESSAGES = "messages_json"
        private const val KEY_LAST_FRIEND = "last_selected_friend"
        private const val KEY_PENDING_QUEUE = "pending_queue_json"
    }

    fun getLoggedInProfile(): UserProfile? {
        val phone = prefs.getString(KEY_PHONE, null) ?: return null
        val name = prefs.getString(KEY_NAME, null) ?: phone
        val avatar = prefs.getString(KEY_AVATAR, null)
        return UserProfile(phone = phone, name = name, avatarBase64 = avatar)
    }

    fun saveProfile(profile: UserProfile) {
        prefs.edit()
            .putString(KEY_PHONE, profile.phone)
            .putString(KEY_NAME, profile.name)
            .putString(KEY_AVATAR, profile.avatarBase64)
            .apply()
    }

    fun getLastSelectedFriend(): String? = prefs.getString(KEY_LAST_FRIEND, null)

    fun saveLastSelectedFriend(phone: String?) {
        if (phone.isNullOrBlank()) prefs.edit().remove(KEY_LAST_FRIEND).apply()
        else prefs.edit().putString(KEY_LAST_FRIEND, phone).apply()
    }

    fun loadFriends(): List<Friend> {
        val raw = prefs.getString(KEY_FRIENDS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<Friend>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val phone = obj.getString("phone")
            list.add(
                Friend(
                    phone = phone,
                    name = obj.optString("name", phone),
                    avatarBase64 = obj.optString("avatarBase64", "").ifBlank { null },
                    isOnline = obj.optBoolean("isOnline", false)
                )
            )
        }
        return list
    }

    fun saveFriends(friends: List<Friend>) {
        val arr = JSONArray()
        friends.forEach { f ->
            arr.put(JSONObject().apply {
                put("phone", f.phone)
                put("name", f.name)
                put("avatarBase64", f.avatarBase64 ?: "")
                put("isOnline", f.isOnline)
            })
        }
        prefs.edit().putString(KEY_FRIENDS, arr.toString()).apply()
    }

    fun loadIncomingRequests(): List<FriendRequest> {
        val raw = prefs.getString(KEY_REQUESTS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<FriendRequest>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val phone = obj.getString("phone")
            list.add(
                FriendRequest(
                    phone = phone,
                    name = obj.optString("name", phone),
                    avatarBase64 = obj.optString("avatarBase64", "").ifBlank { null },
                    isOnline = obj.optBoolean("isOnline", false),
                    createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }
        return list
    }

    fun saveIncomingRequests(requests: List<FriendRequest>) {
        val arr = JSONArray()
        requests.forEach { r ->
            arr.put(JSONObject().apply {
                put("phone", r.phone)
                put("name", r.name)
                put("avatarBase64", r.avatarBase64 ?: "")
                put("isOnline", r.isOnline)
                put("createdAt", r.createdAt)
            })
        }
        prefs.edit().putString(KEY_REQUESTS, arr.toString()).apply()
    }

    fun loadPendingQueue(): List<PendingOutboundPacket> {
        val raw = prefs.getString(KEY_PENDING_QUEUE, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<PendingOutboundPacket>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                PendingOutboundPacket(
                    id = obj.getString("id"),
                    toPhone = obj.getString("toPhone"),
                    payloadJson = obj.getString("payloadJson")
                )
            )
        }
        return list
    }

    fun savePendingQueue(queue: List<PendingOutboundPacket>) {
        val arr = JSONArray()
        queue.forEach { item ->
            arr.put(JSONObject().apply {
                put("id", item.id)
                put("toPhone", item.toPhone)
                put("payloadJson", item.payloadJson)
            })
        }
        prefs.edit().putString(KEY_PENDING_QUEUE, arr.toString()).apply()
    }

    fun loadActiveMessages(): List<ChatMessage> {
        val now = System.currentTimeMillis()
        val raw = prefs.getString(KEY_MESSAGES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val valid = mutableListOf<ChatMessage>()
        var changed = false

        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val expiresAt = obj.getLong("expiresAt")
            val filePath = obj.optString("localFilePath", "").ifBlank { null }
            if (expiresAt <= now) {
                changed = true
                filePath?.let { path -> runCatching { File(path).delete() } }
                continue
            }
            valid.add(
                ChatMessage(
                    id = obj.getString("id"),
                    peerPhone = obj.getString("peerPhone"),
                    senderPhone = obj.getString("senderPhone"),
                    type = runCatching { MessageType.valueOf(obj.getString("type")) }.getOrDefault(MessageType.TEXT),
                    text = obj.optString("text", ""),
                    localFilePath = filePath,
                    timestamp = obj.getLong("timestamp"),
                    expiresAt = expiresAt,
                    isRead = obj.optBoolean("isRead", false),
                    status = runCatching { DeliveryStatus.valueOf(obj.getString("status", "SENT")) }.getOrDefault(DeliveryStatus.SENT)
                )
            )
        }
        if (changed) saveMessages(valid)
        purgeOrphanedTempFiles(valid.mapNotNull { it.localFilePath }.toSet())
        return valid
    }

    fun saveMessages(messages: List<ChatMessage>) {
        val now = System.currentTimeMillis()
        val arr = JSONArray()
        messages.filter { it.expiresAt > now }.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id)
                put("peerPhone", m.peerPhone)
                put("senderPhone", m.senderPhone)
                put("type", m.type.name)
                put("text", m.text)
                put("localFilePath", m.localFilePath ?: "")
                put("timestamp", m.timestamp)
                put("expiresAt", m.expiresAt)
                put("isRead", m.isRead)
                put("status", m.status.name)
            })
        }
        prefs.edit().putString(KEY_MESSAGES, arr.toString()).apply()
    }

    fun createEphemeralFile(prefix: String, extension: String): File {
        return File(ephemeralDir, "${prefix}_${UUID.randomUUID()}.$extension")
    }

    fun purgeOrphanedTempFiles(activePaths: Set<String>) {
        val now = System.currentTimeMillis()
        ephemeralDir.listFiles()?.forEach { file ->
            if (!activePaths.contains(file.absolutePath) && (now - file.lastModified() > 60_000L)) {
                runCatching { file.delete() }
            }
        }
    }
}

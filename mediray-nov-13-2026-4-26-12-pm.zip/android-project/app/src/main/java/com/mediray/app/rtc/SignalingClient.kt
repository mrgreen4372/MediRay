package com.mediray.app.rtc

import com.mediray.app.data.Friend
import com.mediray.app.data.FriendRequest
import com.mediray.app.data.LookupUserResult
import com.mediray.app.data.RelationshipStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

sealed class SignalingEvent {
    data class RegisteredBundle(
        val friends: List<Friend>,
        val incomingRequests: List<FriendRequest>
    ) : SignalingEvent()

    data class PresenceUpdate(
        val phone: String,
        val online: Boolean,
        val name: String?,
        val avatarBase64: String?
    ) : SignalingEvent()

    data class FriendRequestReceived(val request: FriendRequest) : SignalingEvent()
    data class FriendAccepted(val friend: Friend) : SignalingEvent()
    data class RelayAck(val messageId: String, val deliveredNow: Boolean) : SignalingEvent()

    data class RtcOffer(val from: String, val sdp: String) : SignalingEvent()
    data class RtcAnswer(val from: String, val sdp: String) : SignalingEvent()
    data class RtcIce(val from: String, val sdpMid: String, val sdpMLineIndex: Int, val candidate: String) : SignalingEvent()
    data class RelayMessage(val from: String, val payload: JSONObject) : SignalingEvent()
    data class ReceiptUpdate(val isRead: Boolean, val messageIds: List<String>) : SignalingEvent()
}

class SignalingClient(
    private val apiBaseUrl: String,
    private val wsUrl: String
) {
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    private var webSocket: WebSocket? = null
    private var currentPhone: String = ""
    private var currentName: String = ""
    private var currentAvatar: String? = null

    private val _isConnected = MutableStateFlow(false)
    val isConnected = _isConnected.asStateFlow()

    private val _events = MutableSharedFlow<SignalingEvent>(extraBufferCapacity = 64)
    val events = _events.asSharedFlow()

    suspend fun requestFreeOtp(phone: String): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject().put("phone", phone).toString().toRequestBody(jsonMedia)
            val req = Request.Builder().url("$apiBaseUrl/api/auth/request-otp").post(body).build()
            client.newCall(req).execute().use { resp ->
                val obj = JSONObject(resp.body?.string() ?: "{}")
                if (!resp.isSuccessful) error(obj.optString("error", "OTP failed"))
                obj.getString("phone") to obj.getString("freeOtp")
            }
        }
    }

    suspend fun verifyOtp(phone: String, code: String, name: String): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject().apply {
                put("phone", phone)
                put("code", code)
                put("name", name)
            }.toString().toRequestBody(jsonMedia)
            val req = Request.Builder().url("$apiBaseUrl/api/auth/verify-otp").post(body).build()
            client.newCall(req).execute().use { resp ->
                val obj = JSONObject(resp.body?.string() ?: "{}")
                if (!resp.isSuccessful) error(obj.optString("error", "Verification failed"))
                obj.getJSONObject("user")
            }
        }
    }

    suspend fun lookupUser(phone: String, requesterPhone: String): Result<LookupUserResult> = withContext(Dispatchers.IO) {
        runCatching {
            val qPhone = URLEncoder.encode(phone, "UTF-8")
            val qReq = URLEncoder.encode(requesterPhone, "UTF-8")
            val req = Request.Builder().url("$apiBaseUrl/api/users/lookup?phone=$qPhone&requester=$qReq").get().build()
            client.newCall(req).execute().use { resp ->
                val obj = JSONObject(resp.body?.string() ?: "{}")
                if (!resp.isSuccessful) error(obj.optString("error", "Lookup failed"))
                if (!obj.optBoolean("found", false)) {
                    LookupUserResult(found = false, phone = obj.optString("phone", phone))
                } else {
                    val u = obj.getJSONObject("user")
                    val rel = when (u.optString("relationship", "none")) {
                        "friend" -> RelationshipStatus.FRIEND
                        "outgoing_pending" -> RelationshipStatus.OUTGOING_PENDING
                        "incoming_pending" -> RelationshipStatus.INCOMING_PENDING
                        else -> RelationshipStatus.NONE
                    }
                    LookupUserResult(
                        found = true,
                        phone = u.getString("phone"),
                        name = u.optString("name", "").ifBlank { null },
                        avatarBase64 = u.optString("avatarDataUrl", "").ifBlank { null },
                        isOnline = u.optBoolean("online", false),
                        relationship = rel
                    )
                }
            }
        }
    }

    suspend fun sendFriendRequest(fromPhone: String, toPhone: String): Result<Pair<RelationshipStatus, Friend?>> = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject().apply {
                put("fromPhone", fromPhone)
                put("toPhone", toPhone)
            }.toString().toRequestBody(jsonMedia)
            val req = Request.Builder().url("$apiBaseUrl/api/friends/request").post(body).build()
            client.newCall(req).execute().use { resp ->
                val obj = JSONObject(resp.body?.string() ?: "{}")
                if (!resp.isSuccessful) error(obj.optString("error", "Request failed"))
                val status = if (obj.optString("status") == "friend") RelationshipStatus.FRIEND else RelationshipStatus.OUTGOING_PENDING
                val friendObj = obj.optJSONObject("friend")
                val friend = friendObj?.let {
                    Friend(
                        phone = it.getString("phone"),
                        name = it.optString("name", it.getString("phone")),
                        avatarBase64 = it.optString("avatarDataUrl", "").ifBlank { null },
                        isOnline = it.optBoolean("online", false)
                    )
                }
                status to friend
            }
        }
    }

    suspend fun acceptFriendRequest(phone: String, friendPhone: String): Result<Friend> = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject().apply {
                put("phone", phone)
                put("friendPhone", friendPhone)
            }.toString().toRequestBody(jsonMedia)
            val req = Request.Builder().url("$apiBaseUrl/api/friends/accept").post(body).build()
            client.newCall(req).execute().use { resp ->
                val obj = JSONObject(resp.body?.string() ?: "{}")
                if (!resp.isSuccessful) error(obj.optString("error", "Accept failed"))
                val f = obj.getJSONObject("friend")
                Friend(
                    phone = f.getString("phone"),
                    name = f.optString("name", f.getString("phone")),
                    avatarBase64 = f.optString("avatarDataUrl", "").ifBlank { null },
                    isOnline = f.optBoolean("online", false)
                )
            }
        }
    }

    suspend fun declineFriendRequest(phone: String, friendPhone: String) = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject().apply {
                put("phone", phone)
                put("friendPhone", friendPhone)
            }.toString().toRequestBody(jsonMedia)
            val req = Request.Builder().url("$apiBaseUrl/api/friends/decline").post(body).build()
            client.newCall(req).execute().close()
        }
    }

    fun connect(phone: String, name: String, avatarBase64: String?) {
        currentPhone = phone
        currentName = name
        currentAvatar = avatarBase64

        webSocket?.close(1000, "Reconnect")
        val request = Request.Builder().url(wsUrl).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                _isConnected.value = true
                sendJson(JSONObject().apply {
                    put("type", "register")
                    put("phone", currentPhone)
                    put("name", currentName)
                    if (!currentAvatar.isNullOrBlank()) put("avatarDataUrl", currentAvatar)
                })
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching {
                    val json = JSONObject(text)
                    when (json.optString("type")) {
                        "registered" -> {
                            val fArr = json.optJSONArray("friends") ?: JSONArray()
                            val friends = (0 until fArr.length()).map { i ->
                                val o = fArr.getJSONObject(i)
                                Friend(
                                    phone = o.getString("phone"),
                                    name = o.optString("name", o.getString("phone")),
                                    avatarBase64 = o.optString("avatarDataUrl", "").ifBlank { null },
                                    isOnline = o.optBoolean("online", false)
                                )
                            }
                            val rArr = json.optJSONArray("incomingRequests") ?: JSONArray()
                            val requests = (0 until rArr.length()).map { i ->
                                val o = rArr.getJSONObject(i)
                                FriendRequest(
                                    phone = o.getString("phone"),
                                    name = o.optString("name", o.getString("phone")),
                                    avatarBase64 = o.optString("avatarDataUrl", "").ifBlank { null },
                                    isOnline = o.optBoolean("online", false),
                                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                                )
                            }
                            _events.tryEmit(SignalingEvent.RegisteredBundle(friends, requests))
                        }
                        "presence-update" -> {
                            _events.tryEmit(
                                SignalingEvent.PresenceUpdate(
                                    phone = json.getString("phone"),
                                    online = json.optBoolean("online", false),
                                    name = json.optString("name", "").ifBlank { null },
                                    avatarBase64 = json.optString("avatarDataUrl", "").ifBlank { null }
                                )
                            )
                        }
                        "friend-request-received" -> {
                            val o = json.getJSONObject("from")
                            _events.tryEmit(
                                SignalingEvent.FriendRequestReceived(
                                    FriendRequest(
                                        phone = o.getString("phone"),
                                        name = o.optString("name", o.getString("phone")),
                                        avatarBase64 = o.optString("avatarDataUrl", "").ifBlank { null },
                                        isOnline = o.optBoolean("online", false),
                                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                                    )
                                )
                            )
                        }
                        "friend-accepted" -> {
                            val o = json.getJSONObject("friend")
                            _events.tryEmit(
                                SignalingEvent.FriendAccepted(
                                    Friend(
                                        phone = o.getString("phone"),
                                        name = o.optString("name", o.getString("phone")),
                                        avatarBase64 = o.optString("avatarDataUrl", "").ifBlank { null },
                                        isOnline = o.optBoolean("online", false)
                                    )
                                )
                            )
                        }
                        "relay-ack" -> {
                            val id = json.optString("messageId", "")
                            if (id.isNotBlank()) {
                                _events.tryEmit(SignalingEvent.RelayAck(id, json.optBoolean("deliveredNow", false)))
                            }
                        }
                        "rtc-offer" -> {
                            val sdpObj = json.getJSONObject("sdp")
                            _events.tryEmit(SignalingEvent.RtcOffer(json.getString("from"), sdpObj.getString("sdp")))
                        }
                        "rtc-answer" -> {
                            val sdpObj = json.getJSONObject("sdp")
                            _events.tryEmit(SignalingEvent.RtcAnswer(json.getString("from"), sdpObj.getString("sdp")))
                        }
                        "rtc-ice" -> {
                            val cand = json.getJSONObject("candidate")
                            _events.tryEmit(
                                SignalingEvent.RtcIce(
                                    from = json.getString("from"),
                                    sdpMid = cand.optString("sdpMid", ""),
                                    sdpMLineIndex = cand.optInt("sdpMLineIndex", 0),
                                    candidate = cand.getString("candidate")
                                )
                            )
                        }
                        "relay-message" -> {
                            _events.tryEmit(SignalingEvent.RelayMessage(json.getString("from"), json.getJSONObject("payload")))
                        }
                        "msg-ack", "msg-read" -> {
                            val arr = json.optJSONArray("messageIds") ?: JSONArray()
                            val ids = (0 until arr.length()).map { arr.getString(it) }
                            _events.tryEmit(SignalingEvent.ReceiptUpdate(json.optString("type") == "msg-read", ids))
                        }
                    }
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                _isConnected.value = false
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _isConnected.value = false
            }
        })
    }

    fun sendReceipt(to: String, isRead: Boolean, messageIds: List<String>) {
        sendJson(JSONObject().apply {
            put("type", if (isRead) "msg-read" else "msg-ack")
            put("to", to)
            put("messageIds", JSONArray(messageIds))
        })
    }

    fun sendOffer(to: String, sdp: String) {
        sendJson(JSONObject().apply {
            put("type", "rtc-offer")
            put("to", to)
            put("from", currentPhone)
            put("sdp", JSONObject().put("type", "offer").put("sdp", sdp))
        })
    }

    fun sendAnswer(to: String, sdp: String) {
        sendJson(JSONObject().apply {
            put("type", "rtc-answer")
            put("to", to)
            put("from", currentPhone)
            put("sdp", JSONObject().put("type", "answer").put("sdp", sdp))
        })
    }

    fun sendIceCandidate(to: String, sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        sendJson(JSONObject().apply {
            put("type", "rtc-ice")
            put("to", to)
            put("from", currentPhone)
            put("candidate", JSONObject().apply {
                put("sdpMid", sdpMid)
                put("sdpMLineIndex", sdpMLineIndex)
                put("candidate", candidate)
            })
        })
    }

    fun sendRelayPayload(to: String, payload: JSONObject): Boolean {
        if (!_isConnected.value) return false
        return sendJson(JSONObject().apply {
            put("type", "relay-message")
            put("to", to)
            put("from", currentPhone)
            put("payload", payload)
        })
    }

    private fun sendJson(json: JSONObject): Boolean {
        return webSocket?.send(json.toString()) == true
    }

    fun disconnect() {
        webSocket?.close(1000, "User disconnected")
        _isConnected.value = false
    }
}

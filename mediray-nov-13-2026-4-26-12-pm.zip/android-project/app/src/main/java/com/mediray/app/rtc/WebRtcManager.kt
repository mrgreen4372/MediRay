package com.mediray.app.rtc

import android.content.Context
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap

class WebRtcManager(
    context: Context,
    private val signalingClient: SignalingClient
) {
    private val peerConnections = ConcurrentHashMap<String, PeerConnection>()
    private val dataChannels = ConcurrentHashMap<String, DataChannel>()

    private val _connectedPeers = MutableStateFlow<Set<String>>(emptySet())
    val connectedPeers = _connectedPeers.asStateFlow()

    private val _incomingPayloads = MutableSharedFlow<Pair<String, JSONObject>>(extraBufferCapacity = 64)
    val incomingPayloads = _incomingPayloads.asSharedFlow()

    private val factory: PeerConnectionFactory

    init {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
                .createInitializationOptions()
        )
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    private fun createPeerConnection(peerId: String): PeerConnection? {
        peerConnections[peerId]?.let { return it }

        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        val config = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }

        val pc = factory.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                signalingClient.sendIceCandidate(
                    to = peerId,
                    sdpMid = candidate.sdpMid ?: "",
                    sdpMLineIndex = candidate.sdpMLineIndex,
                    candidate = candidate.sdp
                )
            }

            override fun onDataChannel(dc: DataChannel) {
                attachDataChannel(peerId, dc)
            }

            override fun onSignalingChange(state: PeerConnection.SignalingState) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
                if (state == PeerConnection.IceConnectionState.DISCONNECTED ||
                    state == PeerConnection.IceConnectionState.CLOSED ||
                    state == PeerConnection.IceConnectionState.FAILED
                ) {
                    _connectedPeers.value = _connectedPeers.value - peerId
                }
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
            override fun onAddStream(stream: MediaStream) {}
            override fun onRemoveStream(stream: MediaStream) {}
            override fun onRenegotiationNeeded() {}
        })

        if (pc != null) {
            peerConnections[peerId] = pc
        }
        return pc
    }

    private fun attachDataChannel(peerId: String, dc: DataChannel) {
        dataChannels[peerId] = dc
        dc.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previousAmount: Long) {}
            override fun onStateChange() {
                if (dc.state() == DataChannel.State.OPEN) {
                    _connectedPeers.value = _connectedPeers.value + peerId
                } else if (dc.state() == DataChannel.State.CLOSED) {
                    _connectedPeers.value = _connectedPeers.value - peerId
                }
            }

            override fun onMessage(buffer: DataChannel.Buffer) {
                val bytes = ByteArray(buffer.data.remaining())
                buffer.data.get(bytes)
                val raw = String(bytes, StandardCharsets.UTF_8)
                runCatching {
                    val json = JSONObject(raw)
                    _incomingPayloads.tryEmit(peerId to json)
                }
            }
        })
    }

    fun initiateConnection(peerId: String) {
        val pc = createPeerConnection(peerId) ?: return
        val dc = pc.createDataChannel("mediray-p2p", DataChannel.Init().apply { ordered = true })
        attachDataChannel(peerId, dc)

        pc.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(sdp: SessionDescription) {
                pc.setLocalDescription(SimpleSdpObserver(), sdp)
                signalingClient.sendOffer(peerId, sdp.description)
            }
        }, MediaConstraints())
    }

    fun handleOffer(from: String, sdpText: String) {
        val pc = createPeerConnection(from) ?: return
        val remoteSdp = SessionDescription(SessionDescription.Type.OFFER, sdpText)
        pc.setRemoteDescription(object : SimpleSdpObserver() {
            override fun onSetSuccess() {
                pc.createAnswer(object : SimpleSdpObserver() {
                    override fun onCreateSuccess(answerSdp: SessionDescription) {
                        pc.setLocalDescription(SimpleSdpObserver(), answerSdp)
                        signalingClient.sendAnswer(from, answerSdp.description)
                    }
                }, MediaConstraints())
            }
        }, remoteSdp)
    }

    fun handleAnswer(from: String, sdpText: String) {
        val pc = peerConnections[from] ?: return
        pc.setRemoteDescription(
            SimpleSdpObserver(),
            SessionDescription(SessionDescription.Type.ANSWER, sdpText)
        )
    }

    fun handleIce(from: String, sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        val pc = createPeerConnection(from) ?: return
        pc.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, candidate))
    }

    fun sendPayload(peerId: String, payload: JSONObject): Boolean {
        val dc = dataChannels[peerId]
        if (dc != null && dc.state() == DataChannel.State.OPEN) {
            val bytes = payload.toString().toByteArray(StandardCharsets.UTF_8)
            val buffer = DataChannel.Buffer(ByteBuffer.wrap(bytes), false)
            if (dc.send(buffer)) {
                return true
            }
        }
        return signalingClient.sendRelayPayload(peerId, payload)
    }

    fun closeAll() {
        dataChannels.values.forEach { runCatching { it.close() } }
        peerConnections.values.forEach { runCatching { it.close() } }
        dataChannels.clear()
        peerConnections.clear()
        _connectedPeers.value = emptySet()
    }

    private open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(sdp: SessionDescription) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetFailure(error: String?) {}
    }
}

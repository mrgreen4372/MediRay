package com.mediray.app.ui.screens

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mediray.app.data.*
import com.mediray.app.ui.MediRayViewModel
import com.mediray.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatsScreen(
    vm: MediRayViewModel,
    onOpenCameraForFriend: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val profile by vm.profile.collectAsState()
    val friends by vm.friends.collectAsState()
    val incomingRequests by vm.incomingRequests.collectAsState()
    val messages by vm.messages.collectAsState()
    val activeChatPhone by vm.activeChatPhone.collectAsState()
    val p2pPeers by vm.p2pConnectedPeers.collectAsState()
    val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    var searchQuery by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    var lookupResult by remember { mutableStateOf<LookupUserResult?>(null) }

    val activeFriend = friends.find { it.phone == activeChatPhone }

    if (activeChatPhone != null && activeFriend != null) {
        val peerMsgs = messages.filter { it.peerPhone == activeFriend.phone }.sortedBy { it.timestamp }
        var draft by remember { mutableStateOf("") }
        val isP2p = p2pPeers.contains(activeFriend.phone)

        Column(modifier = Modifier.fillMaxSize().background(MediRayCanvas)) {
            Surface(color = MediRaySurface, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { vm.openChatThread(null) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MediRayDeepBlue)
                    }
                    FriendAvatar(name = activeFriend.name, avatarBase64 = activeFriend.avatarBase64, sizeDp = 40)
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(activeFriend.name, fontWeight = FontWeight.Bold, color = MediRaySlate)
                        Text(
                            text = when {
                                isP2p -> "Online (P2P)"
                                activeFriend.isOnline -> "Online"
                                else -> "Offline"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isP2p || activeFriend.isOnline) MediRayOnline else MediRayMuted
                        )
                    }
                    IconButton(onClick = { onOpenCameraForFriend(activeFriend.phone) }) {
                        Icon(Icons.Filled.CameraAlt, contentDescription = "Camera", tint = MediRayDeepBlue)
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(peerMsgs, key = { it.id }) { msg ->
                    val isMine = msg.senderPhone == profile?.phone
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isMine) MediRayBlue else MediRayBubbleIn,
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (msg.type == MessageType.IMAGE && msg.localFilePath != null) {
                                    val bmp = remember(msg.localFilePath) { BitmapFactory.decodeFile(msg.localFilePath) }
                                    if (bmp != null) {
                                        Image(
                                            bitmap = bmp.asImageBitmap(),
                                            contentDescription = "Photo",
                                            modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(10.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                                if (msg.text.isNotBlank()) {
                                    Text(msg.text, color = if (isMine) Color.White else MediRaySlate)
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = timeFmt.format(Date(msg.timestamp)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isMine) Color(0xFFE0F2FE) else MediRayMuted
                                    )
                                    if (isMine) {
                                        val tick = when (msg.status) {
                                            DeliveryStatus.PENDING -> "Pending"
                                            DeliveryStatus.SENT -> "✓"
                                            DeliveryStatus.DELIVERED -> "✓✓"
                                            DeliveryStatus.READ -> "✓✓"
                                        }
                                        Text(
                                            text = tick,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = when (msg.status) {
                                                DeliveryStatus.PENDING -> Color(0xFFFDE68A)
                                                DeliveryStatus.READ -> Color(0xFFBAE6FD)
                                                else -> Color(0xFFE0F2FE)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Surface(color = MediRaySurface, shadowElevation = 4.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("মেসেজ লিখুন...") },
                        singleLine = true,
                        shape = RoundedCornerShape(22.dp)
                    )
                    IconButton(
                        onClick = {
                            if (draft.isNotBlank()) {
                                vm.sendTextMessage(activeFriend.phone, draft)
                                draft = ""
                            }
                        }
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = MediRayDeepBlue)
                    }
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().background(MediRayCanvas).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("মোবাইল নম্বর দিয়ে বন্ধু খুঁজুন") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp)
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                searching = true
                                searchError = null
                                vm.lookupUser(searchQuery)
                                    .onSuccess { lookupResult = it }
                                    .onFailure { searchError = it.message }
                                searching = false
                            }
                        },
                        enabled = !searching && searchQuery.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = MediRayBlue),
                        modifier = Modifier.height(54.dp)
                    ) {
                        Text(if (searching) "..." else "Search", color = Color.White)
                    }
                }
            }

            if (searchError != null) {
                item {
                    Text(searchError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }

            if (lookupResult != null) {
                val res = lookupResult!!
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MediRaySurface)
                    ) {
                        if (!res.found) {
                            Text(
                                "${res.phone} নম্বরে কোনো MediRay ব্যবহারকারী পাওয়া যায়নি",
                                color = MediRayMuted,
                                modifier = Modifier.padding(14.dp)
                            )
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                FriendAvatar(name = res.name ?: res.phone, avatarBase64 = res.avatarBase64, sizeDp = 46)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(res.name ?: res.phone, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text(res.phone, style = MaterialTheme.typography.bodySmall, color = MediRayMuted)
                                }
                                when {
                                    res.phone == profile?.phone -> Text("আপনি", color = MediRayMuted)
                                    res.relationship == RelationshipStatus.FRIEND -> {
                                        Button(onClick = { vm.openChatThread(res.phone) }) { Text("Chat") }
                                    }
                                    res.relationship == RelationshipStatus.OUTGOING_PENDING -> {
                                        Text("Sent", color = MediRayDeepBlue, fontWeight = FontWeight.SemiBold)
                                    }
                                    res.relationship == RelationshipStatus.INCOMING_PENDING -> {
                                        Button(onClick = {
                                            scope.launch {
                                                vm.acceptFriendRequest(res.phone)
                                                lookupResult = res.copy(relationship = RelationshipStatus.FRIEND)
                                            }
                                        }) { Text("Accept") }
                                    }
                                    else -> {
                                        Button(
                                            onClick = {
                                                scope.launch {
                                                    vm.sendFriendRequest(res.phone).onSuccess { nextRel ->
                                                        lookupResult = res.copy(relationship = nextRel)
                                                    }
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MediRayBlue)
                                        ) {
                                            Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Add Friend")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (incomingRequests.isNotEmpty()) {
                item {
                    Text(
                        "বন্ধুত্বের অনুরোধ (${incomingRequests.size})",
                        style = MaterialTheme.typography.labelLarge,
                        color = MediRayDeepBlue
                    )
                }
                items(incomingRequests, key = { it.phone }) { req ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MediRaySurface)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            FriendAvatar(name = req.name, avatarBase64 = req.avatarBase64, sizeDp = 44)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(req.name, fontWeight = FontWeight.SemiBold, color = Color.White)
                                Text(req.phone, style = MaterialTheme.typography.bodySmall, color = MediRayMuted)
                            }
                            Button(
                                onClick = { scope.launch { vm.acceptFriendRequest(req.phone) } },
                                colors = ButtonDefaults.buttonColors(containerColor = MediRayBlue)
                            ) {
                                Text("Accept")
                            }
                            IconButton(onClick = { scope.launch { vm.declineFriendRequest(req.phone) } }) {
                                Icon(Icons.Filled.Close, contentDescription = "Decline", tint = MediRayMuted)
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    "বন্ধুদের চ্যাট (${friends.size})",
                    style = MaterialTheme.typography.labelLarge,
                    color = MediRayMuted
                )
            }

            items(friends, key = { it.phone }) { friend ->
                val peerMsgs = messages.filter { it.peerPhone == friend.phone }.sortedBy { it.timestamp }
                val last = peerMsgs.lastOrNull()
                val unread = peerMsgs.count { !it.isRead }
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { vm.openChatThread(friend.phone) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MediRaySurface)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FriendAvatar(name = friend.name, avatarBase64 = friend.avatarBase64, sizeDp = 46)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(friend.name, fontWeight = FontWeight.SemiBold, color = MediRaySlate)
                            Text(
                                text = when {
                                    last?.type == MessageType.IMAGE -> "ছবি পাঠানো হয়েছে"
                                    last != null -> last.text
                                    friend.isOnline -> "Online"
                                    else -> friend.phone
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (last == null && friend.isOnline) MediRayOnline else MediRayMuted,
                                maxLines = 1
                            )
                        }
                        if (unread > 0) {
                            Badge(containerColor = MediRayBlue) { Text("$unread") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FriendAvatar(name: String, avatarBase64: String?, sizeDp: Int) {
    val bmp = remember(avatarBase64) {
        if (!avatarBase64.isNullOrBlank()) {
            val clean = avatarBase64.substringAfter(",")
            runCatching {
                val bytes = Base64.decode(clean, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }.getOrNull()
        } else null
    }
    Box(
        modifier = Modifier.size(sizeDp.dp).clip(CircleShape).background(MediRaySkyLight),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(name.take(1).uppercase(), fontWeight = FontWeight.Bold, color = Color(0xFFE0F2FE))
        }
    }
}

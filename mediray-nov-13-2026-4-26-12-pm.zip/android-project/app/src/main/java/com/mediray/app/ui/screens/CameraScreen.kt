package com.mediray.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.mediray.app.data.DeliveryStatus
import com.mediray.app.ui.MediRayViewModel
import com.mediray.app.ui.theme.*
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun CameraScreen(
    vm: MediRayViewModel,
    onGoToChats: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val friends by vm.friends.collectAsState()
    val selectedFriendPhone by vm.selectedFriendPhone.collectAsState()
    val pendingQueue by vm.pendingQueue.collectAsState()

    val activeFriend = friends.find { it.phone == selectedFriendPhone }

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasPermission = it
    }

    LaunchedEffect(Unit) {
        if (!hasPermission) permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    var useBackCamera by remember { mutableStateOf(true) }
    var feedbackBanner by remember { mutableStateOf<String?>(null) }
    var showFriendPicker by remember { mutableStateOf(false) }

    LaunchedEffect(feedbackBanner) {
        if (feedbackBanner != null) {
            delay(2500L)
            feedbackBanner = null
        }
    }

    val imageCapture = remember { ImageCapture.Builder().build() }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (hasPermission) {
            AndroidView(
                factory = { ctx -> PreviewView(ctx) },
                update = { previewView ->
                    val future = ProcessCameraProvider.getInstance(context)
                    future.addListener({
                        val provider = future.get()
                        val preview = Preview.Builder().build().apply {
                            surfaceProvider = previewView.surfaceProvider
                        }
                        val selector = if (useBackCamera) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
                        runCatching {
                            provider.unbindAll()
                            provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture)
                        }
                    }, ContextCompat.getMainExecutor(context))
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Column(
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("ক্যামেরা চালু করতে পারমিশন দিন", color = Color.White)
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    colors = ButtonDefaults.buttonColors(containerColor = MediRayBlue)
                ) {
                    Text("ক্যামেরা চালু করুন", color = Color.White)
                }
            }
        }

        // Top Overlay: Target Friend Selector + Flip Camera
        Row(
            modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = MediRayCanvas.copy(alpha = 0.85f),
                shape = RoundedCornerShape(16.dp),
                onClick = {
                    if (friends.isNotEmpty()) showFriendPicker = true
                    else onGoToChats()
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (activeFriend != null) {
                        Column {
                            Text("পাঠানো হবে", style = MaterialTheme.typography.labelSmall, color = MediRayDeepBlue)
                            Text(activeFriend.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = Color.White)
                    } else {
                        Icon(Icons.Filled.PersonAdd, contentDescription = null, tint = MediRayDeepBlue, modifier = Modifier.size(18.dp))
                        Text(
                            if (friends.isNotEmpty()) "বন্ধু নির্বাচন করুন" else "প্রথমে বন্ধু যোগ করুন",
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            IconButton(
                onClick = { useBackCamera = !useBackCamera },
                modifier = Modifier.clip(CircleShape).background(MediRayCanvas.copy(alpha = 0.85f))
            ) {
                Icon(Icons.Filled.FlipCameraAndroid, contentDescription = "Switch Camera", tint = Color.White)
            }
        }

        if (pendingQueue.isNotEmpty()) {
            Surface(
                color = Color(0xCC78350F),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 74.dp)
            ) {
                Text(
                    text = "${pendingQueue.size}টি ছবি Pending — সংযোগ এলে পাঠানো হবে",
                    color = Color(0xFFFEF3C7),
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        if (feedbackBanner != null) {
            Surface(
                color = MediRayBlue,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 126.dp)
            ) {
                Text(
                    text = feedbackBanner!!,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }
        }

        // Large Center Capture Button (Auto-sends immediately without extra Send button)
        Box(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp),
            contentAlignment = Alignment.Center
        ) {
            IconButton(
                onClick = {
                    val target = activeFriend
                    if (target == null) {
                        if (friends.isNotEmpty()) showFriendPicker = true
                        else onGoToChats()
                        return@IconButton
                    }
                    val temp = File.createTempFile("cam_", ".jpg", context.cacheDir)
                    val opts = ImageCapture.OutputFileOptions.Builder(temp).build()
                    imageCapture.takePicture(opts, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                            val bmp = BitmapFactory.decodeFile(temp.absolutePath)
                            temp.delete()
                            if (bmp != null) {
                                val status = vm.sendPhotoAuto(target.phone, bmp)
                                feedbackBanner = if (status == DeliveryStatus.PENDING) {
                                    "ইন্টারনেট নেই — Pending রাখা হয়েছে"
                                } else {
                                    "${target.name}-কে ছবি পাঠানো হয়েছে"
                                }
                            }
                        }
                        override fun onError(exception: ImageCaptureException) {}
                    })
                },
                enabled = hasPermission,
                modifier = Modifier
                    .size(84.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(5.dp, MediRayBlue, CircleShape)
            ) {
                Icon(
                    Icons.Filled.CameraAlt,
                    contentDescription = "Capture and Auto Send",
                    tint = MediRayBlue,
                    modifier = Modifier.size(34.dp)
                )
            }
        }
    }

    if (showFriendPicker) {
        AlertDialog(
            onDismissRequest = { showFriendPicker = false },
            containerColor = MediRaySurface,
            title = { Text("বন্ধু নির্বাচন করুন", color = Color.White) },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 320.dp)) {
                    items(friends, key = { it.phone }) { friend ->
                        val selected = friend.phone == activeFriend?.phone
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) MediRaySkyLight else MediRayCanvas)
                                .clickable {
                                    vm.selectFriendForCamera(friend.phone)
                                    showFriendPicker = false
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(friend.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text(friend.phone, color = MediRayMuted, style = MaterialTheme.typography.bodySmall)
                            }
                            if (selected) {
                                Icon(Icons.Filled.Check, contentDescription = null, tint = MediRayDeepBlue)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showFriendPicker = false
                    onGoToChats()
                }) {
                    Text("নতুন খুঁজুন", color = MediRayDeepBlue)
                }
            }
        )
    }
}

package com.mediray.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val MediRayBlue = Color(0xFF0284C7)
val MediRayDeepBlue = Color(0xFF38BDF8)
val MediRaySkyLight = Color(0xFF0C4A6E)
val MediRayCanvas = Color(0xFF080F1E)
val MediRaySurface = Color(0xFF0F1A2E)
val MediRayBubbleIn = Color(0xFF132038)
val MediRayBorder = Color(0xFF1E293B)
val MediRayWhite = Color(0xFFFFFFFF)
val MediRaySlate = Color(0xFFF1F5F9)
val MediRayMuted = Color(0xFF94A3B8)
val MediRayOnline = Color(0xFF34D399)

private val MediRayColorScheme = darkColorScheme(
    primary = MediRayBlue,
    onPrimary = Color.White,
    primaryContainer = MediRaySkyLight,
    onPrimaryContainer = Color(0xFFE0F2FE),
    secondary = MediRayDeepBlue,
    onSecondary = Color(0xFF080F1E),
    background = MediRayCanvas,
    onBackground = MediRaySlate,
    surface = MediRaySurface,
    onSurface = MediRaySlate,
    surfaceVariant = MediRayBubbleIn,
    onSurfaceVariant = MediRayMuted,
    outline = MediRayBorder
)

@Composable
fun MediRayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MediRayColorScheme,
        content = content
    )
}

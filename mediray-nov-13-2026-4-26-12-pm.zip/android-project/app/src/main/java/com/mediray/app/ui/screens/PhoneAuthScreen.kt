package com.mediray.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mediray.app.R
import com.mediray.app.ui.MediRayViewModel
import com.mediray.app.ui.theme.MediRayBlue
import com.mediray.app.ui.theme.MediRayCanvas
import com.mediray.app.ui.theme.MediRayDeepBlue
import com.mediray.app.ui.theme.MediRaySkyLight
import com.mediray.app.ui.theme.MediRaySlate
import com.mediray.app.ui.theme.MediRaySurface
import kotlinx.coroutines.launch

@Composable
fun PhoneAuthScreen(vm: MediRayViewModel) {
    val scope = rememberCoroutineScope()
    var step by remember { mutableStateOf(1) }
    var phoneInput by remember { mutableStateOf("") }
    var nameInput by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    var normalizedPhone by remember { mutableStateOf("") }
    var freeOtpHint by remember { mutableStateOf<String?>(null) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize().background(MediRayCanvas).padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MediRaySurface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.mediray_logo),
                    contentDescription = "MediRay",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(72.dp).clip(RoundedCornerShape(18.dp))
                )
                Text("MediRay", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White)

                if (errorMsg != null) {
                    Text(errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                if (step == 1) {
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("মোবাইল নম্বর") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("আপনার নাম") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                loading = true
                                errorMsg = null
                                vm.requestOtp(phoneInput).onSuccess { (norm, otp) ->
                                    normalizedPhone = norm
                                    freeOtpHint = otp
                                    step = 2
                                }.onFailure { errorMsg = it.message }
                                loading = false
                            }
                        },
                        enabled = !loading && phoneInput.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MediRayBlue)
                    ) {
                        Text(if (loading) "Sending OTP..." else "Get Free OTP", color = Color.White)
                    }
                } else {
                    Text(normalizedPhone, fontWeight = FontWeight.Bold, color = MediRaySlate)
                    if (freeOtpHint != null) {
                        Surface(color = MediRaySkyLight, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Free OTP: $freeOtpHint", fontWeight = FontWeight.Bold, color = Color(0xFFE0F2FE))
                                TextButton(onClick = { otpInput = freeOtpHint!! }) { Text("Fill", color = MediRayDeepBlue) }
                            }
                        }
                    }
                    OutlinedTextField(
                        value = otpInput,
                        onValueChange = { otpInput = it },
                        label = { Text("6-Digit OTP") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                loading = true
                                errorMsg = null
                                vm.verifyOtpAndLogin(normalizedPhone, otpInput, nameInput)
                                    .onFailure { errorMsg = it.message }
                                loading = false
                            }
                        },
                        enabled = !loading && otpInput.length >= 4,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MediRayBlue)
                    ) {
                        Text(if (loading) "Verifying..." else "Verify & Continue")
                    }
                    TextButton(onClick = { step = 1 }) { Text("Change Number") }
                }
            }
        }
    }
}

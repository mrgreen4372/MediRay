package com.mediray.app.ui

import android.app.Application
import android.graphics.Bitmap
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mediray.app.BuildConfig
import com.mediray.app.data.*
import com.mediray.app.rtc.SignalingClient
import com.mediray.app.rtc.SignalingEvent
import com.mediray.app.rtc.WebRtcManager
import com.mediray.app.utils.AutoDeleteWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

class MediRayViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = LocalRepository(application)
    private val signaling = SignalingClient(BuildConfig.API_BASE_URL, BuildConfig.SIGNALING_WS_URL)
    private val rtcManager = WebRtcManager(application, signaling)

    private val _profile = MutableStateFlow(repo.getLoggedInProfile())
    val profile = _profile.asStateFlow()

    private val _friends = MutableStateFlow(repo.loadFriends())
    val friends = _friends.asStateFlow()

    private val _incomingRequests = MutableStateFlow(repo.loadIncomingRequests())
    val incomingRequests = _incomingRequests.asStateFlow()

    private val _messages = MutableStateFlow(repo.loadActiveMessages())
    val messages = _messages.asStateFlow()

    private val _pendingQueue = MutableStateFlow(repo.loadPendingQueue())
    val pendingQueue = _pendingQueue.asStateFlow()

    private val _selectedFriendPhone = MutableStateFlow<String?>(
        repo.getLastSelectedFriend() ?: _friends.value.firstOrNull()?.phone
    )
    val selectedFriendPhone = _selectedFriendPhone.asStateFlow()

    private val _activeChatPhone = MutableStateFlow<String?>(null)
    val activeChatPhone = _activeChatPhone.asStateFlow()

    val isSignalingOnline = signaling.isConnected
    val p2pConnectedPeers = rtcManager.connectedPeers

    init {
        AutoDeleteWorker.schedule(application)
        _profile.value?.let { p ->
            signaling.connect(p.phone, p.name, p.avatarBase64)
        }
        observeSignalingEvents()
        observeIncomingRtcPayloads()
        startMaintenanceLoop()
    }

    suspend fun requestOtp(phone: String) = signaling.requestFreeOtp(phone)

    suspend fun verifyOtpAndLogin(phone: String, code: String, name: String): Result<UserProfile> {
        val result = signaling.verifyOtp(phone, code, name)
        return result.map { obj ->
            val p = UserProfile(
                phone = obj.getString("phone"),
                name = obj.optString("name", obj.getString("phone")),
                avatarBase64 = obj.optString("avatarDataUrl", "").ifBlank { null }
            )
            repo.saveProfile(p)
            _profile.value = p
            signaling.connect(p.phone, p.name, p.avatarBase64)
            p
        }
    }

    suspend fun lookupUser(phone: String): Result<LookupUserResult> {
        val requester = _profile.value?.phone ?: ""
        return signaling.lookupUser(PhoneUtils.normalize(phone), requester)
    }

    suspend fun sendFriendRequest(toPhone: String): Result<RelationshipStatus> {
        val me = _profile.value?.phone ?: return Result.failure(IllegalStateException("Not logged in"))
        return signaling.sendFriendRequest(me, toPhone).map { (status, acceptedFriend) ->
            if (status == RelationshipStatus.FRIEND && acceptedFriend != null) {
                addOrUpdateFriend(acceptedFriend)
                _incomingRequests.value = _incomingRequests.value.filterNot { it.phone == acceptedFriend.phone }
                repo.saveIncomingRequests(_incomingRequests.value)
            }
            status
        }
    }

    suspend fun acceptFriendRequest(friendPhone: String) {
        val me = _profile.value?.phone ?: return
        signaling.acceptFriendRequest(me, friendPhone).onSuccess { friend ->
            _incomingRequests.value = _incomingRequests.value.filterNot { it.phone == friendPhone }
            repo.saveIncomingRequests(_incomingRequests.value)
            addOrUpdateFriend(friend)
        }
    }

    suspend fun declineFriendRequest(friendPhone: String) {
        val me = _profile.value?.phone ?: return
        signaling.declineFriendRequest(me, friendPhone)
        _incomingRequests.value = _incomingRequests.value.filterNot { it.phone == friendPhone }
        repo.saveIncomingRequests(_incomingRequests.value)
    }

    fun selectFriendForCamera(phone: String) {
        _selectedFriendPhone.value = phone
        repo.saveLastSelectedFriend(phone)
    }

    fun openChatThread(phone: String?) {
        _activeChatPhone.value = phone
        if (phone != null) {
            selectFriendForCamera(phone)
            val unreadIds = mutableListOf<String>()
            val updated = _messages.value.map { m ->
                if (m.peerPhone == phone && !m.isRead) {
                    unreadIds.add(m.id)
                    m.copy(isRead = true)
                } else m
            }
            _messages.value = updated
            repo.saveMessages(updated)
            if (unreadIds.isNotEmpty()) {
                signaling.sendReceipt(phone, true, unreadIds)
            }
            val friend = _friends.value.find { it.phone == phone }
            if (friend?.isOnline == true) rtcManager.initiateConnection(phone)
        }
    }

    private fun addOrUpdateFriend(friend: Friend) {
        val list = _friends.value.toMutableList()
        val idx = list.indexOfFirst { it.phone == friend.phone }
        if (idx >= 0) list[idx] = friend else list.add(0, friend)
        _friends.value = list
        repo.saveFriends(list)
        if (_selectedFriendPhone.value == null) {
            selectFriendForCamera(friend.phone)
        }
        if (friend.isOnline) rtcManager.initiateConnection(friend.phone)
    }

    private fun observeSignalingEvents() {
        viewModelScope.launch {
            signaling.isConnected.collect { connected ->
                if (connected) flushPendingQueue()
            }
        }

        viewModelScope.launch {
            signaling.events.collect { event ->
                when (event) {
                    is SignalingEvent.RegisteredBundle -> {
                        _friends.value = event.friends
                        repo.saveFriends(event.friends)
                        _incomingRequests.value = event.incomingRequests
                        repo.saveIncomingRequests(event.incomingRequests)
                        val curr = _selectedFriendPhone.value
                        if (curr == null || event.friends.none { it.phone == curr }) {
                            val first = event.friends.firstOrNull()?.phone
                            _selectedFriendPhone.value = first
                            repo.saveLastSelectedFriend(first)
                        }
                        event.friends.filter { it.isOnline }.forEach { rtcManager.initiateConnection(it.phone) }
                        flushPendingQueue()
                    }
                    is SignalingEvent.PresenceUpdate -> {
                        val updated = _friends.value.map { f ->
                            if (f.phone == event.phone) {
                                f.copy(
                                    isOnline = event.online,
                                    name = event.name ?: f.name,
                                    avatarBase64 = event.avatarBase64 ?: f.avatarBase64
                                )
                            } else f
                        }
                        _friends.value = updated
                        repo.saveFriends(updated)
                        if (event.online && updated.any { it.phone == event.phone }) {
                            rtcManager.initiateConnection(event.phone)
                        }
                    }
                    is SignalingEvent.FriendRequestReceived -> {
                        if (_incomingRequests.value.none { it.phone == event.request.phone }) {
                            val next = listOf(event.request) + _incomingRequests.value
                            _incomingRequests.value = next
                            repo.saveIncomingRequests(next)
                        }
                    }
                    is SignalingEvent.FriendAccepted -> {
                        _incomingRequests.value = _incomingRequests.value.filterNot { it.phone == event.friend.phone }
                        repo.saveIncomingRequests(_incomingRequests.value)
                        addOrUpdateFriend(event.friend)
                    }
                    is SignalingEvent.RelayAck -> {
                        updateMessageStatus(
                            event.messageId,
                            if (event.deliveredNow) DeliveryStatus.DELIVERED else DeliveryStatus.SENT
                        )
                    }
                    is SignalingEvent.RtcOffer -> rtcManager.handleOffer(event.from, event.sdp)
                    is SignalingEvent.RtcAnswer -> rtcManager.handleAnswer(event.from, event.sdp)
                    is SignalingEvent.RtcIce -> rtcManager.handleIce(event.from, event.sdpMid, event.sdpMLineIndex, event.candidate)
                    is SignalingEvent.RelayMessage -> handleIncomingPayload(event.from, event.payload)
                    is SignalingEvent.ReceiptUpdate -> {
                        val status = if (event.isRead) DeliveryStatus.READ else DeliveryStatus.DELIVERED
                        event.messageIds.forEach { updateMessageStatus(it, status) }
                    }
                }
            }
        }
    }

    private fun observeIncomingRtcPayloads() {
        viewModelScope.launch {
            rtcManager.incomingPayloads.collect { (from, payload) ->
                handleIncomingPayload(from, payload)
            }
        }
    }

    private fun startMaintenanceLoop() {
        viewModelScope.launch {
            while (true) {
                delay(4_500L)
                flushPendingQueue()
                val now = System.currentTimeMillis()
                val current = _messages.value
                val expired = current.filter { it.expiresAt <= now }
                if (expired.isNotEmpty()) {
                    expired.forEach { msg -> msg.localFilePath?.let { runCatching { File(it).delete() } } }
                    val valid = current.filter { it.expiresAt > now }
                    _messages.value = valid
                    repo.saveMessages(valid)
                    repo.purgeOrphanedTempFiles(valid.mapNotNull { it.localFilePath }.toSet())
                }
            }
        }
    }

    private fun updateMessageStatus(messageId: String, nextStatus: DeliveryStatus) {
        val updated = _messages.value.map { m ->
            if (m.id == messageId && nextStatus.ordinal > m.status.ordinal) {
                m.copy(status = nextStatus)
            } else m
        }
        _messages.value = updated
        repo.saveMessages(updated)
    }

    private fun flushPendingQueue() {
        val queue = _pendingQueue.value
        if (queue.isEmpty() || !signaling.isConnected.value) return
        val remaining = mutableListOf<PendingOutboundPacket>()
        queue.forEach { pkt ->
            val ok = runCatching {
                rtcManager.sendPayload(pkt.toPhone, JSONObject(pkt.payloadJson))
            }.getOrDefault(false)
            if (ok) {
                updateMessageStatus(pkt.id, DeliveryStatus.SENT)
            } else {
                remaining.add(pkt)
            }
        }
        if (remaining.size != queue.size) {
            _pendingQueue.value = remaining
            repo.savePendingQueue(remaining)
        }
    }

    private fun handleIncomingPayload(from: String, payload: JSONObject) {
        val normFrom = PhoneUtils.normalize(from)
        val now = System.currentTimeMillis()
        val id = payload.optString("id", UUID.randomUUID().toString())
        if (_messages.value.any { it.id == id }) return

        val expiresAt = payload.optLong("expiresAt", now + LocalRepository.TTL_MILLIS)
        if (expiresAt <= now) return

        val senderName = payload.optString("senderName", normFrom)
        if (_friends.value.none { it.phone == normFrom }) {
            addOrUpdateFriend(Friend(phone = normFrom, name = senderName, isOnline = true))
        }

        val kind = payload.optString("kind", "TEXT")
        val type = if (kind.equals("IMAGE", ignoreCase = true)) MessageType.IMAGE else MessageType.TEXT

        var savedPath: String? = null
        val imageDataUrl = payload.optString("imageDataUrl", "")
        val fileBase64 = payload.optString("fileBase64", "")
        val rawB64 = when {
            imageDataUrl.contains(",") -> imageDataUrl.substringAfter(",")
            fileBase64.isNotBlank() -> fileBase64
            else -> ""
        }
        if (rawB64.isNotBlank() && type == MessageType.IMAGE) {
            val file = repo.createEphemeralFile("rx", "jpg")
            file.writeBytes(Base64.decode(rawB64, Base64.DEFAULT))
            savedPath = file.absolutePath
        }

        val isOpen = (_activeChatPhone.value == normFrom)
        val msg = ChatMessage(
            id = id,
            peerPhone = normFrom,
            senderPhone = normFrom,
            type = type,
            text = payload.optString("text", ""),
            localFilePath = savedPath,
            timestamp = payload.optLong("timestamp", now),
            expiresAt = expiresAt,
            isRead = isOpen,
            status = DeliveryStatus.DELIVERED
        )
        val updated = _messages.value + msg
        _messages.value = updated
        repo.saveMessages(updated)

        signaling.sendReceipt(normFrom, isOpen, listOf(id))
    }

    fun sendTextMessage(peerPhone: String, text: String) {
        val current = _profile.value ?: return
        val clean = text.trim()
        if (clean.isBlank()) return
        val now = System.currentTimeMillis()
        val expiresAt = now + LocalRepository.TTL_MILLIS
        val id = UUID.randomUUID().toString()

        val payload = JSONObject().apply {
            put("id", id)
            put("kind", MessageType.TEXT.name)
            put("text", clean)
            put("senderName", current.name)
            put("timestamp", now)
            put("expiresAt", expiresAt)
        }
        val sentNow = rtcManager.sendPayload(peerPhone, payload)

        val msg = ChatMessage(
            id = id,
            peerPhone = peerPhone,
            senderPhone = current.phone,
            type = MessageType.TEXT,
            text = clean,
            timestamp = now,
            expiresAt = expiresAt,
            isRead = true,
            status = if (sentNow) DeliveryStatus.SENT else DeliveryStatus.PENDING
        )
        val updated = _messages.value + msg
        _messages.value = updated
        repo.saveMessages(updated)

        if (!sentNow) {
            val nextQueue = _pendingQueue.value + PendingOutboundPacket(id, peerPhone, payload.toString())
            _pendingQueue.value = nextQueue
            repo.savePendingQueue(nextQueue)
        }
    }

    fun sendPhotoAuto(peerPhone: String, bitmap: Bitmap): DeliveryStatus {
        val current = _profile.value ?: return DeliveryStatus.PENDING
        val now = System.currentTimeMillis()
        val expiresAt = now + LocalRepository.TTL_MILLIS
        val id = UUID.randomUUID().toString()

        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 82, baos)
        val bytes = baos.toByteArray()
        val file = repo.createEphemeralFile("img", "jpg").apply { writeBytes(bytes) }
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

        val payload = JSONObject().apply {
            put("id", id)
            put("kind", MessageType.IMAGE.name)
            put("text", "")
            put("imageDataUrl", "data:image/jpeg;base64,$b64")
            put("fileBase64", b64)
            put("senderName", current.name)
            put("timestamp", now)
            put("expiresAt", expiresAt)
        }
        val sentNow = rtcManager.sendPayload(peerPhone, payload)
        val initialStatus = if (sentNow) DeliveryStatus.SENT else DeliveryStatus.PENDING

        val msg = ChatMessage(
            id = id,
            peerPhone = peerPhone,
            senderPhone = current.phone,
            type = MessageType.IMAGE,
            localFilePath = file.absolutePath,
            timestamp = now,
            expiresAt = expiresAt,
            isRead = true,
            status = initialStatus
        )
        val updated = _messages.value + msg
        _messages.value = updated
        repo.saveMessages(updated)

        if (!sentNow) {
            val nextQueue = _pendingQueue.value + PendingOutboundPacket(id, peerPhone, payload.toString())
            _pendingQueue.value = nextQueue
            repo.savePendingQueue(nextQueue)
        }
        return initialStatus
    }

    override fun onCleared() {
        super.onCleared()
        rtcManager.closeAll()
        signaling.disconnect()
    }
}

package com.mediray.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mediray.app.BuildConfig
import com.mediray.app.R
import com.mediray.app.ui.screens.CameraScreen
import com.mediray.app.ui.screens.ChatsScreen
import com.mediray.app.ui.screens.PhoneAuthScreen
import com.mediray.app.ui.theme.*
import kotlinx.coroutines.delay

enum class MediRayMode {
    CAMERA,
    CHATS
}

@Composable
fun MediRayApp(vm: MediRayViewModel = viewModel()) {
    var showSplash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(950L)
        showSplash = false
    }

    if (showSplash) {
        SplashView()
        return
    }

    val profile by vm.profile.collectAsState()
    if (profile == null) {
        PhoneAuthScreen(vm)
        return
    }

    val context = LocalContext.current
    var activeMode by remember { mutableStateOf(MediRayMode.CAMERA) }
    var showAdminDialog by remember { mutableStateOf(false) }
    val messages by vm.messages.collectAsState()
    val incomingRequests by vm.incomingRequests.collectAsState()
    val chatBadge = messages.count { !it.isRead } + incomingRequests.size

    Column(modifier = Modifier.fillMaxSize().background(MediRayCanvas).systemBarsPadding()) {
        Surface(color = MediRaySurface, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.mediray_logo),
                        contentDescription = "MediRay",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp))
                    )
                    Text(
                        text = "MediRay",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MediRayCanvas)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val camSelected = activeMode == MediRayMode.CAMERA
                        Button(
                            onClick = {
                                vm.openChatThread(null)
                                activeMode = MediRayMode.CAMERA
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (camSelected) MediRayBlue else Color.Transparent,
                                contentColor = if (camSelected) Color.White else MediRayMuted
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(9.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Filled.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Camera", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        }

                        val chatSelected = activeMode == MediRayMode.CHATS
                        Button(
                            onClick = { activeMode = MediRayMode.CHATS },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (chatSelected) MediRayBlue else Color.Transparent,
                                contentColor = if (chatSelected) Color.White else MediRayMuted
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(9.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Filled.ChatBubble, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = if (chatBadge > 0) "Chats ($chatBadge)" else "Chats",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    IconButton(
                        onClick = { showAdminDialog = true },
                        modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(MediRayCanvas)
                    ) {
                        Icon(Icons.Filled.Settings, contentDescription = "Admin Settings", tint = MediRayMuted, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (activeMode) {
                MediRayMode.CAMERA -> CameraScreen(
                    vm = vm,
                    onGoToChats = { activeMode = MediRayMode.CHATS }
                )
                MediRayMode.CHATS -> ChatsScreen(
                    vm = vm,
                    onOpenCameraForFriend = { phone ->
                        vm.selectFriendForCamera(phone)
                        vm.openChatThread(null)
                        activeMode = MediRayMode.CAMERA
                    }
                )
            }
        }
    }

    if (showAdminDialog) {
        AlertDialog(
            onDismissRequest = { showAdminDialog = false },
            containerColor = MediRaySurface,
            title = { Text("Admin & Settings", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("অ্যাপ: MediRay (${BuildConfig.APPLICATION_ID})", color = MediRaySlate, style = MaterialTheme.typography.bodySmall)
                    Text("ভার্সন: v${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", color = MediRayMuted, style = MaterialTheme.typography.bodySmall)
                    Text("আপনার নম্বর: ${profile?.phone ?: ""}", color = MediRayMuted, style = MaterialTheme.typography.bodySmall)
                    Button(
                        onClick = {
                            val url = "${BuildConfig.API_BASE_URL}/api/apk/download"
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MediRayBlue),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Download Latest APK", color = Color.White)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAdminDialog = false }) {
                    Text("বন্ধ করুন", color = MediRayDeepBlue)
                }
            }
        )
    }
}

@Composable
private fun SplashView() {
    Box(
        modifier = Modifier.fillMaxSize().background(MediRayCanvas),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.mediray_logo),
                contentDescription = "MediRay",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(96.dp).clip(RoundedCornerShape(24.dp))
            )
            Text(
                text = "MediRay",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

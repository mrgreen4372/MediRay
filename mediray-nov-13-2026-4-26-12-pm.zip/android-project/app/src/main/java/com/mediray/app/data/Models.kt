package com.mediray.app.data

enum class MessageType {
    TEXT,
    IMAGE
}

enum class DeliveryStatus {
    PENDING,
    SENT,
    DELIVERED,
    READ
}

enum class RelationshipStatus {
    NONE,
    FRIEND,
    OUTGOING_PENDING,
    INCOMING_PENDING
}

data class UserProfile(
    val phone: String,
    val name: String,
    val avatarBase64: String? = null
)

data class Friend(
    val phone: String,
    val name: String,
    val avatarBase64: String? = null,
    val isOnline: Boolean = false
)

data class FriendRequest(
    val phone: String,
    val name: String,
    val avatarBase64: String? = null,
    val isOnline: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class LookupUserResult(
    val found: Boolean,
    val phone: String,
    val name: String? = null,
    val avatarBase64: String? = null,
    val isOnline: Boolean = false,
    val relationship: RelationshipStatus = RelationshipStatus.NONE
)

data class ChatMessage(
    val id: String,
    val peerPhone: String,
    val senderPhone: String,
    val type: MessageType,
    val text: String = "",
    val localFilePath: String? = null,
    val timestamp: Long,
    val expiresAt: Long,
    val isRead: Boolean = false,
    val status: DeliveryStatus = DeliveryStatus.SENT
)

data class PendingOutboundPacket(
    val id: String,
    val toPhone: String,
    val payloadJson: String
)

object PhoneUtils {
    fun normalize(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        if (digits.isBlank()) return ""
        if (digits.startsWith("00") && digits.length > 4) return "+${digits.drop(2)}"
        if (digits.startsWith("01") && digits.length == 11) return "+88$digits"
        if (digits.startsWith("8801") && digits.length == 13) return "+$digits"
        return "+$digits"
    }
}

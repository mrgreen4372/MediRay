# MediRay Android App (Kotlin + Jetpack Compose + WebRTC)

Fast, ultra-simple **MediRay** Android Studio project.

## Features
- **Mobile Number + Free OTP Auth**: Register and log in with phone number and free self-hosted OTP (zero paid SMS services, zero Firebase, zero Supabase).
- **Phone Contacts Discovery**: Reads `ContactsContract` numbers and matches registered MediRay users automatically.
- **Opens Directly to Camera**: Launches CameraX immediately with a large shutter button that captures and automatically sends photos to the active chat.
- **Real-Time Messaging & Voice**: Send text, photos, documents, and AAC voice messages over WebRTC `PeerConnection` + `DataChannel` with delivery (`✓✓`) and read receipts.
- **WhatsApp Shortcut**: Save a separate WhatsApp number in Profile and open WhatsApp chats in one tap.
- **3-Tab Bottom Navigation**: `Camera`, `Chats`, `Profile`.

## Build APK
1. Open `MediRay-Android` in **Android Studio**.
2. Set `API_BASE_URL` and `SIGNALING_WS_URL` in `app/build.gradle.kts` to your deployed MediRay server host.
3. Run `./gradlew assembleDebug`.

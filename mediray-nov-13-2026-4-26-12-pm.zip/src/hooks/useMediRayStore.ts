import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ChatMessage,
  Friend,
  FriendRequest,
  LookupUserResult,
  UserProfile,
} from '../types/mediray';

const STORAGE_PROFILE = 'mediray_v3_profile';
const STORAGE_FRIENDS = 'mediray_v3_friends';
const STORAGE_REQUESTS = 'mediray_v3_requests';
const STORAGE_MESSAGES = 'mediray_v3_messages';
const STORAGE_LAST_FRIEND = 'mediray_v3_last_friend';
const STORAGE_PENDING_QUEUE = 'mediray_v3_pending_queue';

const TTL_MS = 30 * 60 * 1000;

interface QueuedPayload {
  id: string;
  to: string;
  payload: Record<string, unknown>;
}

export function normalizePhoneClient(raw: string): string {
  const digits = raw.replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('00') && digits.length > 4) return `+${digits.slice(2)}`;
  if (digits.startsWith('01') && digits.length === 11) return `+88${digits}`;
  if (digits.startsWith('8801') && digits.length === 13) return `+${digits}`;
  return `+${digits}`;
}

function safeReadJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function useMediRayStore() {
  const [profile, setProfile] = useState<UserProfile | null>(() =>
    safeReadJson<UserProfile | null>(STORAGE_PROFILE, null)
  );
  const [friends, setFriends] = useState<Friend[]>(() =>
    safeReadJson<Friend[]>(STORAGE_FRIENDS, [])
  );
  const [incomingRequests, setIncomingRequests] = useState<FriendRequest[]>(() =>
    safeReadJson<FriendRequest[]>(STORAGE_REQUESTS, [])
  );
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const now = Date.now();
    return safeReadJson<ChatMessage[]>(STORAGE_MESSAGES, []).filter((m) => m.expiresAt > now);
  });
  const [selectedFriendPhone, setSelectedFriendPhone] = useState<string | null>(() =>
    localStorage.getItem(STORAGE_LAST_FRIEND)
  );
  const [pendingQueue, setPendingQueue] = useState<QueuedPayload[]>(() =>
    safeReadJson<QueuedPayload[]>(STORAGE_PENDING_QUEUE, [])
  );
  const [wsConnected, setWsConnected] = useState(false);
  const [p2pPeers, setP2pPeers] = useState<Record<string, boolean>>({});
  const [activeChatPhone, setActiveChatPhone] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const pcsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const dcsRef = useRef<Map<string, RTCDataChannel>>(new Map());
  const profileRef = useRef(profile);
  const friendsRef = useRef(friends);
  const activeChatRef = useRef(activeChatPhone);
  const pendingQueueRef = useRef(pendingQueue);

  profileRef.current = profile;
  friendsRef.current = friends;
  activeChatRef.current = activeChatPhone;
  pendingQueueRef.current = pendingQueue;

  useEffect(() => {
    if (profile) localStorage.setItem(STORAGE_PROFILE, JSON.stringify(profile));
    else localStorage.removeItem(STORAGE_PROFILE);
  }, [profile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_FRIENDS, JSON.stringify(friends));
  }, [friends]);

  useEffect(() => {
    localStorage.setItem(STORAGE_REQUESTS, JSON.stringify(incomingRequests));
  }, [incomingRequests]);

  useEffect(() => {
    const now = Date.now();
    const active = messages.filter((m) => m.expiresAt > now);
    localStorage.setItem(STORAGE_MESSAGES, JSON.stringify(active));
  }, [messages]);

  useEffect(() => {
    if (selectedFriendPhone) {
      localStorage.setItem(STORAGE_LAST_FRIEND, selectedFriendPhone);
    } else {
      localStorage.removeItem(STORAGE_LAST_FRIEND);
    }
  }, [selectedFriendPhone]);

  useEffect(() => {
    localStorage.setItem(STORAGE_PENDING_QUEUE, JSON.stringify(pendingQueue));
  }, [pendingQueue]);

  // Auto-purge expired 30-minute messages
  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      setMessages((prev) => {
        const next = prev.filter((m) => m.expiresAt > now);
        return next.length === prev.length ? prev : next;
      });
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const sendWs = useCallback((payload: unknown) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(payload));
      return true;
    }
    return false;
  }, []);

  const markMessageStatus = useCallback((messageId: string, status: ChatMessage['status']) => {
    setMessages((prev) =>
      prev.map((m) => {
        if (m.id !== messageId) return m;
        const rank = { pending: 0, sent: 1, delivered: 2, read: 3 };
        return rank[status] > rank[m.status] ? { ...m, status } : m;
      })
    );
  }, []);

  const transmitItem = useCallback(
    (item: QueuedPayload): boolean => {
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        return false;
      }

      const dc = dcsRef.current.get(item.to);
      if (dc && dc.readyState === 'open') {
        try {
          dc.send(JSON.stringify(item.payload));
          markMessageStatus(item.id, 'sent');
          return true;
        } catch {
          // fallback to WS relay
        }
      }

      const sentOverWs = sendWs({
        type: 'relay-message',
        to: item.to,
        from: profileRef.current?.phone,
        payload: item.payload,
      });

      return sentOverWs;
    },
    [markMessageStatus, sendWs]
  );

  // Flush pending offline photos/messages when connection returns
  const flushPendingQueue = useCallback(() => {
    const queue = pendingQueueRef.current;
    if (queue.length === 0) return;
    if (typeof navigator !== 'undefined' && !navigator.onLine) return;
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

    const remaining: QueuedPayload[] = [];
    for (const item of queue) {
      const ok = transmitItem(item);
      if (!ok) remaining.push(item);
    }
    if (remaining.length !== queue.length) {
      setPendingQueue(remaining);
    }
  }, [transmitItem]);

  useEffect(() => {
    const onOnline = () => flushPendingQueue();
    window.addEventListener('online', onOnline);
    const interval = setInterval(flushPendingQueue, 4000);
    return () => {
      window.removeEventListener('online', onOnline);
      clearInterval(interval);
    };
  }, [flushPendingQueue]);

  const handleIncomingPayload = useCallback(
    (fromPhone: string, payload: Record<string, unknown>) => {
      const cleanFrom = normalizePhoneClient(fromPhone);
      const now = Date.now();
      const id = typeof payload.id === 'string' ? payload.id : `${now}-${Math.random()}`;
      const expiresAt = typeof payload.expiresAt === 'number' ? payload.expiresAt : now + TTL_MS;
      if (expiresAt <= now) return;

      const senderName =
        typeof payload.senderName === 'string' && payload.senderName.trim()
          ? payload.senderName.trim()
          : cleanFrom;

      setFriends((prev) => {
        if (prev.some((f) => f.phone === cleanFrom)) {
          return prev.map((f) => (f.phone === cleanFrom ? { ...f, online: true } : f));
        }
        return [...prev, { phone: cleanFrom, name: senderName, online: true }];
      });

      const isCurrentlyOpen = activeChatRef.current === cleanFrom;
      const msg: ChatMessage = {
        id,
        peerPhone: cleanFrom,
        senderPhone: cleanFrom,
        kind: payload.kind === 'IMAGE' ? 'IMAGE' : 'TEXT',
        text: typeof payload.text === 'string' ? payload.text : '',
        imageDataUrl: typeof payload.imageDataUrl === 'string' ? payload.imageDataUrl : undefined,
        timestamp: typeof payload.timestamp === 'number' ? payload.timestamp : now,
        expiresAt,
        isRead: isCurrentlyOpen,
        status: 'delivered',
      };

      setMessages((prev) => {
        if (prev.some((m) => m.id === id)) return prev;
        return [...prev, msg];
      });

      sendWs({
        type: isCurrentlyOpen ? 'msg-read' : 'msg-ack',
        to: cleanFrom,
        messageIds: [id],
      });
    },
    [sendWs]
  );

  const ensurePeerConnection = useCallback(
    (peerPhone: string, initiator: boolean) => {
      const clean = normalizePhoneClient(peerPhone);
      if (!clean || clean === profileRef.current?.phone) return null;

      let pc = pcsRef.current.get(clean);
      if (pc && pc.connectionState !== 'closed' && pc.connectionState !== 'failed') {
        return pc;
      }

      pc = new RTCPeerConnection({
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
        ],
      });
      pcsRef.current.set(clean, pc);

      const attachDataChannel = (dc: RTCDataChannel) => {
        dcsRef.current.set(clean, dc);
        dc.onopen = () => {
          setP2pPeers((prev) => ({ ...prev, [clean]: true }));
        };
        dc.onclose = () => {
          setP2pPeers((prev) => ({ ...prev, [clean]: false }));
        };
        dc.onmessage = (ev) => {
          try {
            const parsed = JSON.parse(String(ev.data)) as Record<string, unknown>;
            handleIncomingPayload(clean, parsed);
          } catch {
            // ignore malformed packet
          }
        };
      };

      pc.ondatachannel = (ev) => attachDataChannel(ev.channel);

      pc.onicecandidate = (ev) => {
        if (ev.candidate) {
          sendWs({
            type: 'rtc-ice',
            to: clean,
            from: profileRef.current?.phone,
            candidate: ev.candidate,
          });
        }
      };

      pc.onconnectionstatechange = () => {
        if (pc && (pc.connectionState === 'failed' || pc.connectionState === 'closed')) {
          setP2pPeers((prev) => ({ ...prev, [clean]: false }));
        }
      };

      if (initiator) {
        const dc = pc.createDataChannel('mediray-p2p', { ordered: true });
        attachDataChannel(dc);
        pc.createOffer()
          .then((offer) => pc!.setLocalDescription(offer).then(() => offer))
          .then((offer) => {
            sendWs({
              type: 'rtc-offer',
              to: clean,
              from: profileRef.current?.phone,
              sdp: offer,
            });
          })
          .catch(() => {});
      }

      return pc;
    },
    [handleIncomingPayload, sendWs]
  );

  // Connect & maintain WebSocket lifecycle
  useEffect(() => {
    if (!profile?.phone) return;

    let cancelled = false;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const connect = () => {
      if (cancelled) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        ws.send(
          JSON.stringify({
            type: 'register',
            phone: profile.phone,
            name: profile.name,
            avatarDataUrl: profile.avatarDataUrl,
          })
        );
      };

      ws.onmessage = async (event) => {
        try {
          const data = JSON.parse(String(event.data));
          if (data.type === 'registered') {
            if (Array.isArray(data.friends)) {
              setFriends(data.friends);
              // Keep last selected friend if valid, otherwise default to first friend
              setSelectedFriendPhone((curr) => {
                if (curr && data.friends.some((f: Friend) => f.phone === curr)) return curr;
                return data.friends[0]?.phone || null;
              });
              for (const f of data.friends as Friend[]) {
                if (f.online) ensurePeerConnection(f.phone, true);
              }
            }
            if (Array.isArray(data.incomingRequests)) {
              setIncomingRequests(data.incomingRequests);
            }
            flushPendingQueue();
            return;
          }

          if (data.type === 'presence-update') {
            const p = normalizePhoneClient(String(data.phone || ''));
            setFriends((prev) =>
              prev.map((f) =>
                f.phone === p
                  ? {
                      ...f,
                      online: Boolean(data.online),
                      name: data.name || f.name,
                      avatarDataUrl: data.avatarDataUrl ?? f.avatarDataUrl,
                    }
                  : f
              )
            );
            if (data.online && friendsRef.current.some((f) => f.phone === p)) {
              ensurePeerConnection(p, true);
            }
            return;
          }

          if (data.type === 'friend-request-received' && data.from) {
            const reqUser = data.from as FriendRequest;
            setIncomingRequests((prev) => {
              if (prev.some((r) => r.phone === reqUser.phone)) return prev;
              return [reqUser, ...prev];
            });
            return;
          }

          if (data.type === 'friend-accepted' && data.friend) {
            const accepted = data.friend as Friend;
            setIncomingRequests((prev) => prev.filter((r) => r.phone !== accepted.phone));
            setFriends((prev) => {
              if (prev.some((f) => f.phone === accepted.phone)) {
                return prev.map((f) => (f.phone === accepted.phone ? accepted : f));
              }
              return [accepted, ...prev];
            });
            setSelectedFriendPhone((curr) => curr || accepted.phone);
            if (accepted.online) ensurePeerConnection(accepted.phone, true);
            return;
          }

          if (data.type === 'relay-ack' && typeof data.messageId === 'string') {
            markMessageStatus(data.messageId, data.deliveredNow ? 'delivered' : 'sent');
            return;
          }

          if (data.type === 'rtc-offer' && data.from && data.sdp) {
            const pc = ensurePeerConnection(data.from, false);
            if (pc) {
              await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
              const answer = await pc.createAnswer();
              await pc.setLocalDescription(answer);
              sendWs({
                type: 'rtc-answer',
                to: data.from,
                from: profileRef.current?.phone,
                sdp: answer,
              });
            }
            return;
          }

          if (data.type === 'rtc-answer' && data.from && data.sdp) {
            const pc = pcsRef.current.get(normalizePhoneClient(data.from));
            if (pc) {
              await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
            }
            return;
          }

          if (data.type === 'rtc-ice' && data.from && data.candidate) {
            const pc = pcsRef.current.get(normalizePhoneClient(data.from));
            if (pc) {
              await pc.addIceCandidate(new RTCIceCandidate(data.candidate)).catch(() => {});
            }
            return;
          }

          if (data.type === 'relay-message' && data.from && data.payload) {
            handleIncomingPayload(data.from, data.payload);
            return;
          }

          if ((data.type === 'msg-ack' || data.type === 'msg-read') && Array.isArray(data.messageIds)) {
            const targetStatus = data.type === 'msg-read' ? 'read' : 'delivered';
            for (const id of data.messageIds as string[]) {
              markMessageStatus(id, targetStatus);
            }
          }
        } catch {
          // ignore malformed packet
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (!cancelled) {
          reconnectTimer = setTimeout(connect, 2500);
        }
      };
    };

    connect();

    return () => {
      cancelled = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      wsRef.current?.close();
      pcsRef.current.forEach((pc) => pc.close());
      pcsRef.current.clear();
      dcsRef.current.clear();
    };
  }, [profile?.phone, profile?.name, profile?.avatarDataUrl, ensurePeerConnection, flushPendingQueue, handleIncomingPayload, markMessageStatus, sendWs]);

  const requestOtp = async (rawPhone: string): Promise<{ phone: string; freeOtp: string }> => {
    const res = await fetch('/api/auth/request-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone: rawPhone }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'OTP পাঠানো যায়নি');
    return { phone: json.phone, freeOtp: json.freeOtp };
  };

  const verifyOtpAndLogin = async (
    phone: string,
    code: string,
    name: string,
    avatarDataUrl?: string
  ): Promise<UserProfile> => {
    const res = await fetch('/api/auth/verify-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, code, name }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'OTP কোড সঠিক নয়');
    const userProfile: UserProfile = {
      phone: json.user.phone,
      name: json.user.name || name || json.user.phone,
      avatarDataUrl: avatarDataUrl || json.user.avatarDataUrl,
    };
    setProfile(userProfile);
    return userProfile;
  };

  const lookupUserByPhone = async (rawPhone: string): Promise<LookupUserResult> => {
    const clean = normalizePhoneClient(rawPhone);
    if (!clean || clean.length < 8) {
      throw new Error('সঠিক মোবাইল নম্বর দিন');
    }
    const requester = profile?.phone ? `&requester=${encodeURIComponent(profile.phone)}` : '';
    const res = await fetch(`/api/users/lookup?phone=${encodeURIComponent(clean)}${requester}`);
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'খোঁজা যায়নি');
    if (!json.found) {
      return { found: false, phone: clean };
    }
    return {
      found: true,
      phone: json.user.phone,
      name: json.user.name,
      avatarDataUrl: json.user.avatarDataUrl,
      online: json.user.online,
      relationship: json.user.relationship,
    };
  };

  const sendFriendRequest = async (toPhone: string) => {
    if (!profile) throw new Error('লগইন করুন');
    const res = await fetch('/api/friends/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fromPhone: profile.phone, toPhone }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'অনুরোধ পাঠানো যায়নি');
    if (json.status === 'friend' && json.friend) {
      setIncomingRequests((prev) => prev.filter((r) => r.phone !== json.friend.phone));
      setFriends((prev) => {
        if (prev.some((f) => f.phone === json.friend.phone)) return prev;
        return [json.friend, ...prev];
      });
      setSelectedFriendPhone((curr) => curr || json.friend.phone);
    }
    return json.status as 'friend' | 'outgoing_pending';
  };

  const acceptFriendRequest = async (friendPhone: string) => {
    if (!profile) return;
    const res = await fetch('/api/friends/accept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone: profile.phone, friendPhone }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Accept করা যায়নি');
    setIncomingRequests((prev) => prev.filter((r) => r.phone !== friendPhone));
    if (json.friend) {
      setFriends((prev) => {
        if (prev.some((f) => f.phone === json.friend.phone)) return prev;
        return [json.friend, ...prev];
      });
      setSelectedFriendPhone((curr) => curr || json.friend.phone);
      if (json.friend.online) ensurePeerConnection(json.friend.phone, true);
    }
  };

  const declineFriendRequest = async (friendPhone: string) => {
    if (!profile) return;
    await fetch('/api/friends/decline', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone: profile.phone, friendPhone }),
    });
    setIncomingRequests((prev) => prev.filter((r) => r.phone !== friendPhone));
  };

  const openChatThread = useCallback(
    (friendPhone: string | null) => {
      setActiveChatPhone(friendPhone);
      if (!friendPhone) return;

      setSelectedFriendPhone(friendPhone);
      const unreadIds: string[] = [];
      setMessages((prev) =>
        prev.map((m) => {
          if (m.peerPhone === friendPhone && !m.isRead) {
            unreadIds.push(m.id);
            return { ...m, isRead: true };
          }
          return m;
        })
      );
      if (unreadIds.length > 0) {
        sendWs({ type: 'msg-read', to: friendPhone, messageIds: unreadIds });
      }
      const f = friendsRef.current.find((item) => item.phone === friendPhone);
      if (f?.online) ensurePeerConnection(friendPhone, true);
    },
    [ensurePeerConnection, sendWs]
  );

  const sendTextMessage = useCallback(
    (peerPhone: string, text: string) => {
      const current = profileRef.current;
      const clean = text.trim();
      if (!current || !clean) return;

      const now = Date.now();
      const expiresAt = now + TTL_MS;
      const id = crypto.randomUUID ? crypto.randomUUID() : `${now}-${Math.random()}`;
      const payload = {
        id,
        kind: 'TEXT',
        text: clean,
        senderName: current.name,
        timestamp: now,
        expiresAt,
      };

      const item: QueuedPayload = { id, to: peerPhone, payload };
      const sentNow = transmitItem(item);

      setMessages((prev) => [
        ...prev,
        {
          id,
          peerPhone,
          senderPhone: current.phone,
          kind: 'TEXT',
          text: clean,
          timestamp: now,
          expiresAt,
          isRead: true,
          status: sentNow ? 'sent' : 'pending',
        },
      ]);

      if (!sentNow) {
        setPendingQueue((prev) => [...prev, item]);
      }
    },
    [transmitItem]
  );

  const sendPhotoAuto = useCallback(
    (peerPhone: string, imageDataUrl: string): 'sent' | 'pending' => {
      const current = profileRef.current;
      if (!current) return 'pending';

      const now = Date.now();
      const expiresAt = now + TTL_MS;
      const id = crypto.randomUUID ? crypto.randomUUID() : `${now}-${Math.random()}`;
      const payload = {
        id,
        kind: 'IMAGE',
        text: '',
        imageDataUrl,
        senderName: current.name,
        timestamp: now,
        expiresAt,
      };

      const item: QueuedPayload = { id, to: peerPhone, payload };
      const sentNow = transmitItem(item);

      setMessages((prev) => [
        ...prev,
        {
          id,
          peerPhone,
          senderPhone: current.phone,
          kind: 'IMAGE',
          text: '',
          imageDataUrl,
          timestamp: now,
          expiresAt,
          isRead: true,
          status: sentNow ? 'sent' : 'pending',
        },
      ]);

      if (!sentNow) {
        setPendingQueue((prev) => [...prev, item]);
        return 'pending';
      }
      return 'sent';
    },
    [transmitItem]
  );

  return {
    profile,
    friends,
    incomingRequests,
    messages,
    selectedFriendPhone,
    setSelectedFriendPhone,
    activeChatPhone,
    openChatThread,
    wsConnected,
    p2pPeers,
    pendingCount: pendingQueue.length,
    requestOtp,
    verifyOtpAndLogin,
    lookupUserByPhone,
    sendFriendRequest,
    acceptFriendRequest,
    declineFriendRequest,
    sendTextMessage,
    sendPhotoAuto,
  };
}

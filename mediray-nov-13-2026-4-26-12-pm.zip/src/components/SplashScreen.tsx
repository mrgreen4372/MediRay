import React from 'react';
import { MediRayLogo } from './MediRayLogo';

export const SplashScreen: React.FC = () => {
  return (
    <div className="min-h-dvh w-full bg-[#080F1E] flex flex-col items-center justify-center px-6">
      <div className="flex flex-col items-center gap-4 animate-fade-in">
        <div className="w-24 h-24 rounded-3xl overflow-hidden shadow-2xl shadow-red-950/50">
          <MediRayLogo size={96} />
        </div>
        <div className="text-center">
          <h1 className="text-2xl font-bold tracking-tight text-white">MediRay</h1>
          <p className="text-xs text-sky-400 mt-1">Camera &amp; Direct Chat</p>
        </div>
      </div>
    </div>
  );
};

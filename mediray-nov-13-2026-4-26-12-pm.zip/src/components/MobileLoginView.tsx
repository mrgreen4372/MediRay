import React, { useRef, useState } from 'react';
import { Camera, ArrowRight, CheckCircle2, Download } from 'lucide-react';
import { MediRayLogo } from './MediRayLogo';
import { UserProfile } from '../types/mediray';

interface MobileLoginViewProps {
  onRequestOtp: (phone: string) => Promise<{ phone: string; freeOtp: string }>;
  onVerifyOtp: (phone: string, code: string, name: string, avatarDataUrl?: string) => Promise<UserProfile>;
  onOpenAdminSettings?: () => void;
}

export const MobileLoginView: React.FC<MobileLoginViewProps> = ({
  onRequestOtp,
  onVerifyOtp,
  onOpenAdminSettings,
}) => {
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phoneInput, setPhoneInput] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [avatarDataUrl, setAvatarDataUrl] = useState<string | undefined>(undefined);
  const [normalizedPhone, setNormalizedPhone] = useState('');
  const [freeOtp, setFreeOtp] = useState<string | null>(null);
  const [otpInput, setOtpInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 160;
        canvas.height = 160;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const side = Math.min(img.width, img.height);
          const sx = (img.width - side) / 2;
          const sy = (img.height - side) / 2;
          ctx.drawImage(img, sx, sy, side, side, 0, 0, 160, 160);
          setAvatarDataUrl(canvas.toDataURL('image/jpeg', 0.8));
        }
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await onRequestOtp(phoneInput);
      setNormalizedPhone(res.phone);
      setFreeOtp(res.freeOtp);
      setStep('otp');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'OTP পাঠানো যায়নি');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await onVerifyOtp(normalizedPhone, otpInput, nameInput.trim(), avatarDataUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'OTP সঠিক নয়');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-dvh w-full bg-[#080F1E] flex items-center justify-center p-4">
      <div className="w-full max-w-sm rounded-3xl bg-[#0F1A2E] border border-slate-800 p-6 shadow-2xl">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-md mb-3">
            <MediRayLogo size={64} />
          </div>
          <h1 className="text-xl font-bold text-white">MediRay</h1>
          <p className="text-xs text-slate-400 mt-1">মোবাইল নম্বর দিয়ে যুক্ত হোন</p>
        </div>

        {error && (
          <div className="mb-4 rounded-xl bg-rose-950/60 border border-rose-800/60 px-3 py-2 text-xs text-rose-200">
            {error}
          </div>
        )}

        {step === 'phone' ? (
          <form onSubmit={handleSendOtp} className="space-y-4">
            <div className="flex justify-center">
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="relative w-16 h-16 rounded-full bg-[#132038] border border-slate-700 flex items-center justify-center overflow-hidden hover:border-sky-500 transition-colors"
                title="প্রোফাইল ছবি দিন"
              >
                {avatarDataUrl ? (
                  <img src={avatarDataUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <Camera className="w-5 h-5 text-sky-400" />
                )}
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                className="hidden"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 mb-1.5">মোবাইল নম্বর</label>
              <input
                type="tel"
                required
                value={phoneInput}
                onChange={(e) => setPhoneInput(e.target.value)}
                className="w-full min-h-[44px] rounded-xl bg-[#080F1E] border border-slate-700 px-3.5 text-sm text-white focus:outline-none focus:border-sky-500 font-mono-tabular"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 mb-1.5">আপনার নাম</label>
              <input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                className="w-full min-h-[44px] rounded-xl bg-[#080F1E] border border-slate-700 px-3.5 text-sm text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <button
              type="submit"
              disabled={loading || !phoneInput.trim()}
              className="w-full min-h-[46px] rounded-xl bg-[#0284C7] hover:bg-[#0369A1] disabled:opacity-50 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <span>{loading ? 'OTP তৈরি হচ্ছে...' : 'ফ্রি OTP পান'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerify} className="space-y-4">
            <div className="text-center text-sm font-medium text-slate-200 font-mono-tabular">
              {normalizedPhone}
            </div>

            {freeOtp && (
              <div className="rounded-xl bg-sky-950/60 border border-sky-800/70 px-3.5 py-2.5 flex items-center justify-between">
                <span className="text-xs text-sky-200">
                  ফ্রি OTP: <strong className="text-sm font-mono-tabular text-white">{freeOtp}</strong>
                </span>
                <button
                  type="button"
                  onClick={() => setOtpInput(freeOtp)}
                  className="text-xs font-semibold text-sky-400 hover:text-sky-300 px-2 py-1"
                >
                  বসান
                </button>
              </div>
            )}

            <div>
              <label className="block text-xs text-slate-300 mb-1.5">৬-সংখ্যার OTP</label>
              <input
                type="text"
                inputMode="numeric"
                required
                value={otpInput}
                onChange={(e) => setOtpInput(e.target.value)}
                placeholder="6-digit OTP"
                className="w-full min-h-[44px] rounded-xl bg-[#080F1E] border border-slate-700 px-3.5 text-center text-base tracking-widest text-white placeholder:text-slate-500 focus:outline-none focus:border-sky-500 font-mono-tabular"
              />
            </div>

            <button
              type="submit"
              disabled={loading || otpInput.trim().length < 4}
              className="w-full min-h-[46px] rounded-xl bg-[#0284C7] hover:bg-[#0369A1] disabled:opacity-50 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{loading ? 'যাচাই হচ্ছে...' : 'শুরু করুন'}</span>
            </button>

            <button
              type="button"
              onClick={() => setStep('phone')}
              className="w-full py-2 text-xs text-slate-400 hover:text-slate-200"
            >
              নম্বর পরিবর্তন করুন
            </button>
          </form>
        )}

        {onOpenAdminSettings && (
          <div className="mt-5 pt-4 border-t border-slate-800/80 flex justify-center">
            <button
              type="button"
              onClick={onOpenAdminSettings}
              className="min-h-[40px] px-3 text-xs font-medium text-sky-400 hover:text-sky-300 flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Admin / Download APK</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

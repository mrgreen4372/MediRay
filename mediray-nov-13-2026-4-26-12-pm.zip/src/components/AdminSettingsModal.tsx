import React, { useEffect, useState } from 'react';
import { Download, X, Copy, Check, Smartphone, RefreshCw } from 'lucide-react';
import { MediRayLogo } from './MediRayLogo';

interface ApkInfo {
  available: boolean;
  appName: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  fileName: string;
  sizeBytes: number;
  sha256: string;
  updatedAt: number | null;
  downloadUrl: string;
}

interface AdminSettingsModalProps {
  open: boolean;
  onClose: () => void;
}

export const AdminSettingsModal: React.FC<AdminSettingsModalProps> = ({ open, onClose }) => {
  const [info, setInfo] = useState<ApkInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [building, setBuilding] = useState(false);
  const [copied, setCopied] = useState(false);
  const [buildError, setBuildError] = useState<string | null>(null);

  const loadInfo = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/apk-info');
      if (res.ok) {
        const data = (await res.json()) as ApkInfo;
        setInfo(data);
      }
    } catch {
      // ignore network error
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      setBuildError(null);
      loadInfo();
    }
  }, [open]);

  if (!open) return null;

  const fullDownloadUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}${info?.downloadUrl || '/api/download-apk'}`
      : '/api/download-apk';

  const formatSize = (bytes: number) => {
    if (!bytes) return '0 MB';
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(fullDownloadUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore clipboard error
    }
  };

  const handleRebuild = async () => {
    setBuilding(true);
    setBuildError(null);
    try {
      const res = await fetch('/api/admin/build-apk', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) {
        setBuildError(data.error || 'APK তৈরি করা যায়নি');
      } else {
        await loadInfo();
      }
    } catch {
      setBuildError('সার্ভারের সাথে সংযোগ ব্যর্থ হয়েছে');
    } finally {
      setBuilding(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl bg-[#0F1A2E] border border-slate-800 p-6 shadow-2xl space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <MediRayLogo size={42} />
            <div>
              <h2 className="text-base font-bold text-white">Admin &amp; Settings</h2>
              <p className="text-xs text-slate-400">Android Release APK</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="বন্ধ করুন"
            className="min-w-[40px] min-h-[40px] rounded-xl bg-[#080F1E] text-slate-300 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="rounded-2xl bg-[#080F1E] border border-slate-800 p-4 space-y-2 text-xs">
          <div className="flex items-center justify-between text-slate-300">
            <span>App Name</span>
            <span className="font-semibold text-white">{info?.appName || 'MediRay'}</span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span>Package Name</span>
            <span className="font-mono-tabular text-sky-400">{info?.packageName || 'com.mediray.app'}</span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span>Version</span>
            <span className="font-mono-tabular text-white">
              v{info?.versionName || '1.0.0'} ({info?.versionCode || 1})
            </span>
          </div>
          {info?.available && (
            <>
              <div className="flex items-center justify-between text-slate-300">
                <span>APK Size</span>
                <span className="font-mono-tabular text-white">{formatSize(info.sizeBytes)}</span>
              </div>
              {info.sha256 && (
                <div className="pt-1 border-t border-slate-800/80">
                  <div className="text-slate-400 mb-0.5">SHA-256</div>
                  <div className="font-mono-tabular text-[10px] text-slate-300 break-all">
                    {info.sha256}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {buildError && (
          <div className="rounded-xl bg-rose-950/60 border border-rose-800/60 px-3 py-2 text-xs text-rose-200">
            {buildError}
          </div>
        )}

        <div className="space-y-2.5">
          {loading ? (
            <div className="min-h-[48px] rounded-2xl bg-[#132038] text-slate-300 text-sm flex items-center justify-center">
              লোড হচ্ছে...
            </div>
          ) : info?.available ? (
            <>
              <a
                href={info.downloadUrl}
                download={info.fileName}
                className="w-full min-h-[48px] rounded-2xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Download APK ({formatSize(info.sizeBytes)})</span>
              </a>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="flex-1 min-h-[42px] rounded-xl bg-[#080F1E] border border-slate-700 hover:border-slate-600 text-xs font-medium text-slate-200 flex items-center justify-center gap-1.5"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'লিংক কপি হয়েছে' : 'ডাউনলোড লিংক কপি'}</span>
                </button>

                <button
                  type="button"
                  disabled={building}
                  onClick={handleRebuild}
                  className="min-h-[42px] px-3.5 rounded-xl bg-[#080F1E] border border-slate-700 hover:border-slate-600 text-xs font-medium text-slate-200 flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${building ? 'animate-spin' : ''}`} />
                  <span>{building ? 'তৈরি হচ্ছে...' : 'Rebuild'}</span>
                </button>
              </div>
            </>
          ) : (
            <button
              type="button"
              disabled={building}
              onClick={handleRebuild}
              className="w-full min-h-[48px] rounded-2xl bg-[#0284C7] hover:bg-[#0369A1] disabled:opacity-50 text-white text-sm font-semibold flex items-center justify-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${building ? 'animate-spin' : ''}`} />
              <span>{building ? 'Release APK তৈরি হচ্ছে...' : 'Release APK তৈরি করুন'}</span>
            </button>
          )}

          <div className="flex items-start gap-2 pt-1 text-[11px] text-slate-400 leading-relaxed">
            <Smartphone className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
            <span>
              ডাউনলোড করা APK অন্য ফোনে পাঠিয়ে সরাসরি ইনস্টল করতে পারবেন (প্রথমবার Install from Unknown Sources অনুমতি দিন)।
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

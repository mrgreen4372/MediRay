import React, { useEffect, useRef, useState } from 'react';
import {
  Search,
  UserPlus,
  Check,
  X,
  ArrowLeft,
  Send,
  Camera,
  Clock,
  CheckCheck,
} from 'lucide-react';
import { ChatMessage, Friend, FriendRequest, LookupUserResult } from '../types/mediray';

interface ChatsViewProps {
  myPhone: string;
  friends: Friend[];
  incomingRequests: FriendRequest[];
  messages: ChatMessage[];
  activeChatPhone: string | null;
  p2pPeers: Record<string, boolean>;
  onOpenChat: (phone: string | null) => void;
  onSearchPhone: (phone: string) => Promise<LookupUserResult>;
  onAddFriend: (phone: string) => Promise<'friend' | 'outgoing_pending'>;
  onAcceptRequest: (phone: string) => Promise<void>;
  onDeclineRequest: (phone: string) => Promise<void>;
  onSendText: (phone: string, text: string) => void;
  onOpenCameraForFriend: (phone: string) => void;
}

export const ChatsView: React.FC<ChatsViewProps> = ({
  myPhone,
  friends,
  incomingRequests,
  messages,
  activeChatPhone,
  p2pPeers,
  onOpenChat,
  onSearchPhone,
  onAddFriend,
  onAcceptRequest,
  onDeclineRequest,
  onSendText,
  onOpenCameraForFriend,
}) => {
  const [searchInput, setSearchInput] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [searchResult, setSearchResult] = useState<LookupUserResult | null>(null);
  const [addingFriend, setAddingFriend] = useState(false);
  const [draft, setDraft] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  const activeFriend = friends.find((f) => f.phone === activeChatPhone) || null;
  const threadMessages = activeChatPhone
    ? messages
        .filter((m) => m.peerPhone === activeChatPhone)
        .sort((a, b) => a.timestamp - b.timestamp)
    : [];

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [threadMessages.length, activeChatPhone]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;
    setSearching(true);
    setSearchError(null);
    setSearchResult(null);
    try {
      const res = await onSearchPhone(searchInput.trim());
      setSearchResult(res);
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : 'খোঁজা যায়নি');
    } finally {
      setSearching(false);
    }
  };

  const handleAddFriendClick = async (targetPhone: string) => {
    setAddingFriend(true);
    try {
      const nextStatus = await onAddFriend(targetPhone);
      setSearchResult((prev) =>
        prev ? { ...prev, relationship: nextStatus } : prev
      );
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : 'অনুরোধ পাঠানো যায়নি');
    } finally {
      setAddingFriend(false);
    }
  };

  const formatTime = (ts: number) =>
    new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Direct Chat Thread
  if (activeChatPhone && activeFriend) {
    const isP2p = Boolean(p2pPeers[activeFriend.phone]);

    return (
      <div className="flex-1 flex flex-col bg-[#080F1E] min-h-0">
        {/* Chat Thread Header */}
        <div className="px-3 py-2.5 bg-[#0F1A2E] border-b border-slate-800 flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onOpenChat(null)}
            aria-label="পিছনে যান"
            className="min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center text-sky-400 hover:bg-[#132038]"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="w-10 h-10 rounded-full bg-[#132038] text-sky-300 font-bold flex items-center justify-center overflow-hidden shrink-0">
            {activeFriend.avatarDataUrl ? (
              <img
                src={activeFriend.avatarDataUrl}
                alt={activeFriend.name}
                className="w-full h-full object-cover"
              />
            ) : (
              activeFriend.name.slice(0, 1).toUpperCase()
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-white truncate">{activeFriend.name}</div>
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <span className={activeFriend.online || isP2p ? 'text-emerald-400' : 'text-slate-400'}>
                {isP2p ? 'অনলাইন (P2P)' : activeFriend.online ? 'অনলাইন' : 'অফলাইন'}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-tabular">{activeFriend.phone}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onOpenCameraForFriend(activeFriend.phone)}
            aria-label="ক্যামেরা দিয়ে ছবি পাঠান"
            className="min-w-[44px] min-h-[44px] rounded-xl bg-[#0284C7] text-white flex items-center justify-center hover:bg-[#0369A1]"
          >
            <Camera className="w-5 h-5" />
          </button>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto px-3.5 py-4 space-y-2.5">
          {threadMessages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center py-12 text-slate-400 text-xs">
              <p>এখনো কোনো মেসেজ নেই।</p>
              <p className="mt-1">টেক্সট লিখুন বা ক্যামেরা দিয়ে সরাসরি ছবি পাঠান।</p>
            </div>
          )}

          {threadMessages.map((msg) => {
            const isMine = msg.senderPhone === myPhone;
            return (
              <div key={msg.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 shadow-sm ${
                    isMine
                      ? 'bg-[#0284C7] text-white rounded-br-sm'
                      : 'bg-[#132038] text-slate-100 border border-slate-800 rounded-bl-sm'
                  }`}
                >
                  {msg.kind === 'IMAGE' && msg.imageDataUrl && (
                    <img
                      src={msg.imageDataUrl}
                      alt="MediRay Photo"
                      className="rounded-xl max-h-64 w-auto object-cover mb-1.5"
                    />
                  )}
                  {msg.text && <p className="text-sm leading-relaxed break-words">{msg.text}</p>}

                  <div
                    className={`mt-1 flex items-center justify-end gap-1 text-[11px] font-mono-tabular ${
                      isMine ? 'text-sky-100/90' : 'text-slate-400'
                    }`}
                  >
                    <span>{formatTime(msg.timestamp)}</span>
                    {isMine && (
                      <>
                        {msg.status === 'pending' && (
                          <span className="inline-flex items-center gap-0.5 text-amber-200">
                            <Clock className="w-3 h-3" /> Pending
                          </span>
                        )}
                        {msg.status === 'sent' && <Check className="w-3.5 h-3.5" />}
                        {msg.status === 'delivered' && <CheckCheck className="w-3.5 h-3.5" />}
                        {msg.status === 'read' && (
                          <CheckCheck className="w-3.5 h-3.5 text-sky-200" />
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={endRef} />
        </div>

        {/* Simple Text Composer */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!draft.trim()) return;
            onSendText(activeFriend.phone, draft);
            setDraft('');
          }}
          className="px-3 py-2.5 bg-[#0F1A2E] border-t border-slate-800 flex items-center gap-2 shrink-0"
        >
          <input
            type="text"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="মেসেজ লিখুন..."
            className="flex-1 min-h-[44px] rounded-2xl bg-[#080F1E] border border-slate-700 px-4 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-sky-500"
          />
          <button
            type="submit"
            disabled={!draft.trim()}
            aria-label="পাঠান"
            className="min-w-[44px] min-h-[44px] rounded-2xl bg-[#0284C7] hover:bg-[#0369A1] disabled:opacity-40 text-white flex items-center justify-center transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    );
  }

  // Friends Search + Requests + Chat List
  return (
    <div className="flex-1 bg-[#080F1E] overflow-y-auto px-4 py-4">
      <div className="max-w-2xl mx-auto space-y-5">
        {/* Mobile Number Search Box */}
        <form onSubmit={handleSearch} className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="tel"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="মোবাইল নম্বর দিয়ে বন্ধু খুঁজুন"
              className="w-full min-h-[46px] rounded-2xl bg-[#0F1A2E] border border-slate-800 pl-10 pr-4 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-sky-500 font-mono-tabular"
            />
          </div>
          <button
            type="submit"
            disabled={searching || !searchInput.trim()}
            className="min-h-[46px] px-4 rounded-2xl bg-[#0284C7] hover:bg-[#0369A1] disabled:opacity-50 text-white text-sm font-medium shrink-0"
          >
            {searching ? '...' : 'Search'}
          </button>
        </form>

        {searchError && (
          <div className="rounded-2xl bg-rose-950/60 border border-rose-800/60 px-4 py-3 text-xs text-rose-200">
            {searchError}
          </div>
        )}

        {/* Search Result Card */}
        {searchResult && (
          <div className="rounded-2xl bg-[#0F1A2E] border border-slate-800 p-4">
            {!searchResult.found ? (
              <p className="text-sm text-slate-300">
                <span className="font-mono-tabular text-white">{searchResult.phone}</span> নম্বরে কোনো
                MediRay ব্যবহারকারী পাওয়া যায়নি।
              </p>
            ) : (
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-full bg-[#132038] text-sky-300 font-bold flex items-center justify-center overflow-hidden shrink-0">
                  {searchResult.avatarDataUrl ? (
                    <img
                      src={searchResult.avatarDataUrl}
                      alt={searchResult.name || searchResult.phone}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    (searchResult.name || searchResult.phone).slice(0, 1).toUpperCase()
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white truncate">
                    {searchResult.name || searchResult.phone}
                  </div>
                  <div className="text-xs text-slate-400 font-mono-tabular">
                    {searchResult.phone} · {searchResult.online ? 'অনলাইন' : 'অফলাইন'}
                  </div>
                </div>

                {searchResult.phone === myPhone ? (
                  <span className="text-xs text-slate-400">আপনি</span>
                ) : searchResult.relationship === 'friend' ? (
                  <button
                    type="button"
                    onClick={() => onOpenChat(searchResult.phone)}
                    className="min-h-[40px] px-4 rounded-xl bg-[#0284C7] text-white text-xs font-semibold"
                  >
                    Chat
                  </button>
                ) : searchResult.relationship === 'outgoing_pending' ? (
                  <span className="text-xs font-medium text-sky-400 px-2">Request Sent</span>
                ) : searchResult.relationship === 'incoming_pending' ? (
                  <button
                    type="button"
                    onClick={() => onAcceptRequest(searchResult.phone)}
                    className="min-h-[40px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
                  >
                    Accept
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={addingFriend}
                    onClick={() => handleAddFriendClick(searchResult.phone)}
                    className="min-h-[40px] px-3.5 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Add Friend</span>
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* Incoming Friend Requests */}
        {incomingRequests.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-xs font-semibold text-sky-400">
              বন্ধুত্বের অনুরোধ ({incomingRequests.length})
            </h2>
            {incomingRequests.map((req) => (
              <div
                key={req.phone}
                className="rounded-2xl bg-[#0F1A2E] border border-sky-800/50 p-3.5 flex items-center gap-3"
              >
                <div className="w-11 h-11 rounded-full bg-[#132038] text-sky-300 font-bold flex items-center justify-center overflow-hidden shrink-0">
                  {req.avatarDataUrl ? (
                    <img src={req.avatarDataUrl} alt={req.name} className="w-full h-full object-cover" />
                  ) : (
                    req.name.slice(0, 1).toUpperCase()
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white truncate">{req.name}</div>
                  <div className="text-xs text-slate-400 font-mono-tabular">{req.phone}</div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onAcceptRequest(req.phone)}
                    className="min-h-[40px] px-3.5 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-semibold flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Accept</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeclineRequest(req.phone)}
                    aria-label="বাতিল"
                    className="min-w-[40px] min-h-[40px] rounded-xl bg-[#132038] text-slate-300 hover:text-white flex items-center justify-center"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </section>
        )}

        {/* Friends Chat List */}
        <section className="space-y-2">
          <h2 className="text-xs font-semibold text-slate-400">
            বন্ধুদের চ্যাট ({friends.length})
          </h2>

          {friends.length === 0 ? (
            <div className="rounded-2xl bg-[#0F1A2E] border border-slate-800 p-8 text-center">
              <p className="text-sm text-slate-200 font-medium">এখনো কোনো বন্ধু যুক্ত নেই</p>
              <p className="text-xs text-slate-400 mt-1.5">
                উপরের সার্চ বক্সে বন্ধুর মোবাইল নম্বর লিখে Add Friend করুন।
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80 rounded-2xl bg-[#0F1A2E] border border-slate-800 overflow-hidden">
              {friends.map((friend) => {
                const peerMsgs = messages
                  .filter((m) => m.peerPhone === friend.phone)
                  .sort((a, b) => a.timestamp - b.timestamp);
                const last = peerMsgs[peerMsgs.length - 1];
                const unread = peerMsgs.filter((m) => !m.isRead).length;

                return (
                  <button
                    key={friend.phone}
                    type="button"
                    onClick={() => onOpenChat(friend.phone)}
                    className="w-full min-h-[68px] px-4 py-3 flex items-center gap-3.5 text-left hover:bg-[#132038]/70 transition-colors"
                  >
                    <div className="w-11 h-11 rounded-full bg-[#132038] text-sky-300 font-bold flex items-center justify-center overflow-hidden shrink-0">
                      {friend.avatarDataUrl ? (
                        <img
                          src={friend.avatarDataUrl}
                          alt={friend.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        friend.name.slice(0, 1).toUpperCase()
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-semibold text-white truncate">
                          {friend.name}
                        </span>
                        {last && (
                          <span className="text-[11px] text-slate-400 font-mono-tabular shrink-0">
                            {formatTime(last.timestamp)}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between gap-2 mt-0.5">
                        <span className="text-xs text-slate-400 truncate">
                          {last
                            ? last.kind === 'IMAGE'
                              ? 'ছবি পাঠানো হয়েছে'
                              : last.text
                            : friend.online
                            ? 'অনলাইন'
                            : friend.phone}
                        </span>
                        {unread > 0 && (
                          <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-[#0284C7] text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                            {unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

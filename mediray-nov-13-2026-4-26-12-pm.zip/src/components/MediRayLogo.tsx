import React, { useState } from 'react';

interface MediRayLogoProps {
  size?: number;
  className?: string;
}

export const MediRayLogo: React.FC<MediRayLogoProps> = ({ size = 40, className = '' }) => {
  const [imgFailed, setImgFailed] = useState(false);

  if (imgFailed) {
    return (
      <div
        style={{ width: size, height: size }}
        className={`rounded-xl bg-red-600 text-white font-bold flex items-center justify-center shrink-0 ${className}`}
        aria-label="MediRay Logo"
      >
        MR
      </div>
    );
  }

  return (
    <img
      src="/assets/mediray_logo.png"
      alt="MediRay Logo"
      width={size}
      height={size}
      style={{ width: size, height: size }}
      onError={() => setImgFailed(true)}
      referrerPolicy="no-referrer"
      className={`rounded-xl object-cover shrink-0 ${className}`}
    />
  );
};

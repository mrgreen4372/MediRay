import React, { useEffect, useRef, useState } from 'react';
import { Camera, RefreshCw, ChevronDown, UserPlus, Check, Clock } from 'lucide-react';
import { Friend } from '../types/mediray';

interface CameraMainViewProps {
  friends: Friend[];
  selectedFriendPhone: string | null;
  pendingCount: number;
  onSelectFriend: (phone: string) => void;
  onAutoSendPhoto: (peerPhone: string, dataUrl: string) => 'sent' | 'pending';
  onGoToChats: () => void;
}

export const CameraMainView: React.FC<CameraMainViewProps> = ({
  friends,
  selectedFriendPhone,
  pendingCount,
  onSelectFriend,
  onAutoSendPhoto,
  onGoToChats,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [flashMsg, setFlashMsg] = useState<{ text: string; pending: boolean } | null>(null);
  const [shutterFlash, setShutterFlash] = useState(false);

  const selectedFriend = friends.find((f) => f.phone === selectedFriendPhone) || null;

  useEffect(() => {
    let active = true;

    const startCamera = async () => {
      setCameraError(null);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode },
          audio: false,
        });
        if (!active) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }
      } catch {
        if (active) {
          setCameraError('ক্যামেরা চালু করতে ব্রাউজারের ক্যামেরা পারমিশন দিন');
        }
      }
    };

    startCamera();

    return () => {
      active = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };
  }, [facingMode]);

  const showFeedback = (text: string, pending: boolean) => {
    setFlashMsg({ text, pending });
    setTimeout(() => setFlashMsg(null), 2600);
  };

  const handleCaptureAndAutoSend = () => {
    if (!selectedFriend) {
      if (friends.length > 0) {
        setPickerOpen(true);
      } else {
        onGoToChats();
      }
      return;
    }

    const video = videoRef.current;
    if (!video || video.videoWidth === 0) {
      showFeedback('ক্যামেরা প্রস্তুত হচ্ছে...', true);
      return;
    }

    const maxDim = 1280;
    const scale = Math.min(1, maxDim / Math.max(video.videoWidth, video.videoHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.82);

    setShutterFlash(true);
    setTimeout(() => setShutterFlash(false), 160);

    const status = onAutoSendPhoto(selectedFriend.phone, dataUrl);
    if (status === 'sent') {
      showFeedback(`${selectedFriend.name}-কে ছবি পাঠানো হয়েছে`, false);
    } else {
      showFeedback('ইন্টারনেট নেই — Pending রাখা হয়েছে', true);
    }
  };

  return (
    <div className="relative flex-1 w-full bg-black overflow-hidden flex flex-col">
      {cameraError ? (
        <div className="flex-1 flex flex-col items-center justify-center px-6 text-center bg-[#080F1E]">
          <Camera className="w-12 h-12 text-sky-400 mb-3" />
          <p className="text-sm text-slate-200 max-w-xs">{cameraError}</p>
          <button
            type="button"
            onClick={() => setFacingMode((m) => (m === 'environment' ? 'user' : 'environment'))}
            className="mt-4 min-h-[44px] px-5 rounded-xl bg-[#0284C7] text-white text-sm font-medium"
          >
            আবার চেষ্টা করুন
          </button>
        </div>
      ) : (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover flex-1"
        />
      )}

      {shutterFlash && <div className="absolute inset-0 bg-white/60 pointer-events-none" />}

      {/* Top Overlay: Selected Friend Target & Flip Camera */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-10">
        <button
          type="button"
          onClick={() => {
            if (friends.length > 0) setPickerOpen(true);
            else onGoToChats();
          }}
          className="min-h-[44px] max-w-[75%] px-3.5 py-2 rounded-2xl bg-[#080F1E]/80 backdrop-blur-md border border-slate-700/70 flex items-center gap-2.5 text-left"
        >
          {selectedFriend ? (
            <>
              <div className="w-7 h-7 rounded-full bg-[#0284C7] text-white text-xs font-bold flex items-center justify-center overflow-hidden shrink-0">
                {selectedFriend.avatarDataUrl ? (
                  <img
                    src={selectedFriend.avatarDataUrl}
                    alt={selectedFriend.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  selectedFriend.name.slice(0, 1).toUpperCase()
                )}
              </div>
              <div className="min-w-0">
                <div className="text-[11px] text-sky-300 leading-tight">পাঠানো হবে</div>
                <div className="text-xs font-semibold text-white truncate">{selectedFriend.name}</div>
              </div>
              <ChevronDown className="w-4 h-4 text-slate-300 shrink-0" />
            </>
          ) : (
            <>
              <UserPlus className="w-4 h-4 text-sky-400 shrink-0" />
              <span className="text-xs font-medium text-white truncate">
                {friends.length > 0 ? 'বন্ধু নির্বাচন করুন' : 'প্রথমে বন্ধু যোগ করুন'}
              </span>
            </>
          )}
        </button>

        <button
          type="button"
          onClick={() => setFacingMode((m) => (m === 'environment' ? 'user' : 'environment'))}
          aria-label="ক্যামেরা ঘোরান"
          className="min-w-[44px] min-h-[44px] rounded-full bg-[#080F1E]/80 backdrop-blur-md border border-slate-700/70 text-white flex items-center justify-center"
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      {/* Pending queue notice if offline */}
      {pendingCount > 0 && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-10 px-3.5 py-1.5 rounded-xl bg-amber-950/90 border border-amber-700/70 text-amber-100 text-xs flex items-center gap-1.5 backdrop-blur-md">
          <Clock className="w-3.5 h-3.5 text-amber-300" />
          <span>{pendingCount}টি ছবি Pending — সংযোগ এলে পাঠানো হবে</span>
        </div>
      )}

      {/* Auto-send status feedback */}
      {flashMsg && (
        <div
          className={`absolute bottom-32 left-1/2 -translate-x-1/2 z-20 px-4 py-2 rounded-2xl text-xs font-semibold text-white shadow-lg flex items-center gap-2 whitespace-nowrap ${
            flashMsg.pending ? 'bg-amber-600' : 'bg-[#0284C7]'
          }`}
        >
          {flashMsg.pending ? <Clock className="w-4 h-4" /> : <Check className="w-4 h-4" />}
          <span>{flashMsg.text}</span>
        </div>
      )}

      {/* Large Capture Button (Auto-sends on tap) */}
      <div className="absolute bottom-7 left-0 right-0 flex flex-col items-center gap-2 z-10 pointer-events-none">
        <button
          type="button"
          onClick={handleCaptureAndAutoSend}
          aria-label="ছবি তুলে পাঠান"
          className="pointer-events-auto w-20 h-20 rounded-full bg-white border-[5px] border-[#0284C7] shadow-2xl flex items-center justify-center active:scale-95 transition-transform"
        >
          <Camera className="w-8 h-8 text-[#0284C7]" />
        </button>
      </div>

      {/* Quick Friend Picker Sheet when selecting target friend */}
      {pickerOpen && (
        <div
          className="absolute inset-0 z-30 bg-black/70 backdrop-blur-sm flex items-end justify-center sm:items-center p-0 sm:p-4"
          onClick={() => setPickerOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-[#0F1A2E] border border-slate-800 p-5 max-h-[70vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-white">ছবি পাঠানোর বন্ধু নির্বাচন করুন</h2>
              <button
                type="button"
                onClick={() => {
                  setPickerOpen(false);
                  onGoToChats();
                }}
                className="text-xs text-sky-400 font-medium"
              >
                নতুন খুঁজুন
              </button>
            </div>
            <div className="space-y-2">
              {friends.map((friend) => {
                const isSelected = friend.phone === selectedFriend?.phone;
                return (
                  <button
                    key={friend.phone}
                    type="button"
                    onClick={() => {
                      onSelectFriend(friend.phone);
                      setPickerOpen(false);
                    }}
                    className={`w-full min-h-[52px] p-3 rounded-2xl border flex items-center gap-3 text-left transition-colors ${
                      isSelected
                        ? 'bg-sky-950/60 border-sky-500'
                        : 'bg-[#080F1E] border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-full bg-[#132038] text-sky-300 font-bold flex items-center justify-center overflow-hidden shrink-0">
                      {friend.avatarDataUrl ? (
                        <img
                          src={friend.avatarDataUrl}
                          alt={friend.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        friend.name.slice(0, 1).toUpperCase()
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-white truncate">{friend.name}</div>
                      <div className="text-xs text-slate-400 font-mono-tabular">
                        {friend.phone} · {friend.online ? 'অনলাইন' : 'অফলাইন'}
                      </div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-sky-400 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { Camera, MessageCircle, Settings } from 'lucide-react';
import { MediRayLogo } from './components/MediRayLogo';
import { SplashScreen } from './components/SplashScreen';
import { MobileLoginView } from './components/MobileLoginView';
import { CameraMainView } from './components/CameraMainView';
import { ChatsView } from './components/ChatsView';
import { AdminSettingsModal } from './components/AdminSettingsModal';
import { useMediRayStore } from './hooks/useMediRayStore';
import { MainMode } from './types/mediray';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [mode, setMode] = useState<MainMode>('camera');
  const [adminOpen, setAdminOpen] = useState(false);

  const store = useMediRayStore();

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 950);
    return () => clearTimeout(timer);
  }, []);

  if (showSplash) {
    return <SplashScreen />;
  }

  if (!store.profile) {
    return (
      <>
        <MobileLoginView
          onRequestOtp={store.requestOtp}
          onVerifyOtp={store.verifyOtpAndLogin}
          onOpenAdminSettings={() => setAdminOpen(true)}
        />
        <AdminSettingsModal open={adminOpen} onClose={() => setAdminOpen(false)} />
      </>
    );
  }

  const unreadCount = store.messages.filter((m) => !m.isRead).length;
  const chatBadgeCount = unreadCount + store.incomingRequests.length;

  return (
    <div className="h-dvh w-full bg-[#080F1E] text-slate-100 flex flex-col overflow-hidden">
      {/* Compact Top Bar with ONLY TWO main buttons (Camera & Chats) + Admin/Settings icon for APK Download */}
      <header className="h-14 px-3.5 bg-[#0F1A2E] border-b border-slate-800 flex items-center justify-between gap-3 shrink-0 z-30">
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 rounded-lg overflow-hidden shrink-0">
            <MediRayLogo size={32} />
          </div>
          <span className="text-base font-bold text-white tracking-tight whitespace-nowrap">
            MediRay
          </span>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-[#080F1E] p-1 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => {
                store.openChatThread(null);
                setMode('camera');
              }}
              className={`min-h-[38px] px-3.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                mode === 'camera'
                  ? 'bg-[#0284C7] text-white'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>Camera</span>
            </button>

            <button
              type="button"
              onClick={() => setMode('chats')}
              className={`min-h-[38px] px-3.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                mode === 'chats'
                  ? 'bg-[#0284C7] text-white'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <MessageCircle className="w-4 h-4" />
              <span>Chats</span>
              {chatBadgeCount > 0 && (
                <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-white text-[#0284C7] text-[10px] font-bold flex items-center justify-center">
                  {chatBadgeCount}
                </span>
              )}
            </button>
          </div>

          <button
            type="button"
            onClick={() => setAdminOpen(true)}
            aria-label="Admin & Settings — Download APK"
            title="Admin & Settings (Download APK)"
            className="min-w-[40px] min-h-[40px] rounded-xl bg-[#080F1E] border border-slate-800 text-slate-300 hover:text-white flex items-center justify-center"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Content: Always opens directly to Camera; no bottom Navigation Bar */}
      {mode === 'camera' ? (
        <CameraMainView
          friends={store.friends}
          selectedFriendPhone={store.selectedFriendPhone}
          pendingCount={store.pendingCount}
          onSelectFriend={(phone) => store.setSelectedFriendPhone(phone)}
          onAutoSendPhoto={store.sendPhotoAuto}
          onGoToChats={() => setMode('chats')}
        />
      ) : (
        <ChatsView
          myPhone={store.profile.phone}
          friends={store.friends}
          incomingRequests={store.incomingRequests}
          messages={store.messages}
          activeChatPhone={store.activeChatPhone}
          p2pPeers={store.p2pPeers}
          onOpenChat={store.openChatThread}
          onSearchPhone={store.lookupUserByPhone}
          onAddFriend={store.sendFriendRequest}
          onAcceptRequest={store.acceptFriendRequest}
          onDeclineRequest={store.declineFriendRequest}
          onSendText={store.sendTextMessage}
          onOpenCameraForFriend={(phone) => {
            store.setSelectedFriendPhone(phone);
            store.openChatThread(null);
            setMode('camera');
          }}
        />
      )}

      <AdminSettingsModal open={adminOpen} onClose={() => setAdminOpen(false)} />
    </div>
  );
}

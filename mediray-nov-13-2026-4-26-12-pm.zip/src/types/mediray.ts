export type MainMode = 'camera' | 'chats';

export type DeliveryStatus = 'pending' | 'sent' | 'delivered' | 'read';

export type RelationshipStatus = 'none' | 'friend' | 'outgoing_pending' | 'incoming_pending';

export interface UserProfile {
  phone: string;
  name: string;
  avatarDataUrl?: string;
}

export interface Friend {
  phone: string;
  name: string;
  avatarDataUrl?: string | null;
  online: boolean;
  p2pConnected?: boolean;
}

export interface FriendRequest {
  phone: string;
  name: string;
  avatarDataUrl?: string | null;
  online: boolean;
  createdAt: number;
}

export interface LookupUserResult {
  found: boolean;
  phone: string;
  name?: string;
  avatarDataUrl?: string | null;
  online?: boolean;
  relationship?: RelationshipStatus;
}

export interface ChatMessage {
  id: string;
  peerPhone: string;
  senderPhone: string;
  kind: 'TEXT' | 'IMAGE';
  text: string;
  imageDataUrl?: string;
  timestamp: number;
  expiresAt: number;
  isRead: boolean;
  status: DeliveryStatus;
}

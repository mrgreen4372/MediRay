import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { exec } from 'child_process';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import JSZip from 'jszip';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const MESSAGE_TTL_MS = 30 * 60 * 1000;
const OTP_TTL_MS = 5 * 60 * 1000;
const DATA_DB_FILE = path.join(__dirname, '.mediray-users.json');

interface StoredUser {
  phone: string;
  name: string;
  avatarDataUrl?: string;
  updatedAt: number;
}

interface FriendRequestRecord {
  fromPhone: string;
  toPhone: string;
  createdAt: number;
}

interface PersistedDb {
  users: StoredUser[];
  friendships: Array<[string, string]>;
  friendRequests: FriendRequestRecord[];
}

interface PendingOtp {
  phone: string;
  code: string;
  expiresAt: number;
}

interface PeerRecord {
  ws: WebSocket;
  phone: string;
  name: string;
  avatarDataUrl?: string;
  connectedAt: number;
}

interface EphemeralRelayPacket {
  id: string;
  to: string;
  from: string;
  payload: unknown;
  expiresAt: number;
}

export function normalizePhone(raw: string): string {
  const digits = raw.replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('00') && digits.length > 4) {
    return `+${digits.slice(2)}`;
  }
  if (digits.startsWith('01') && digits.length === 11) {
    return `+88${digits}`;
  }
  if (digits.startsWith('8801') && digits.length === 13) {
    return `+${digits}`;
  }
  return `+${digits}`;
}

function makePairKey(a: string, b: string): string {
  return a < b ? `${a}|${b}` : `${b}|${a}`;
}

function parsePairKey(key: string): [string, string] {
  const [a, b] = key.split('|');
  return [a, b];
}

const usersDb = new Map<string, StoredUser>();
const friendships = new Set<string>();
const friendRequests = new Map<string, FriendRequestRecord>();

function loadDb() {
  try {
    if (!fs.existsSync(DATA_DB_FILE)) return;
    const raw = fs.readFileSync(DATA_DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as PersistedDb | StoredUser[];
    if (Array.isArray(parsed)) {
      for (const u of parsed) {
        if (u?.phone) usersDb.set(u.phone, u);
      }
      return;
    }
    if (Array.isArray(parsed.users)) {
      for (const u of parsed.users) {
        if (u?.phone) usersDb.set(u.phone, u);
      }
    }
    if (Array.isArray(parsed.friendships)) {
      for (const pair of parsed.friendships) {
        if (Array.isArray(pair) && pair.length === 2) {
          friendships.add(makePairKey(pair[0], pair[1]));
        }
      }
    }
    if (Array.isArray(parsed.friendRequests)) {
      for (const req of parsed.friendRequests) {
        if (req?.fromPhone && req?.toPhone) {
          friendRequests.set(`${req.fromPhone}->${req.toPhone}`, req);
        }
      }
    }
  } catch {
    // ignore corrupt local cache
  }
}

function persistDb() {
  try {
    const payload: PersistedDb = {
      users: Array.from(usersDb.values()),
      friendships: Array.from(friendships).map(parsePairKey),
      friendRequests: Array.from(friendRequests.values()),
    };
    fs.writeFileSync(DATA_DB_FILE, JSON.stringify(payload, null, 2));
  } catch {
    // ignore disk errors
  }
}

loadDb();

const pendingOtps = new Map<string, PendingOtp>();
const peers = new Map<string, PeerRecord>();
const ephemeralQueue = new Map<string, EphemeralRelayPacket[]>();

function purgeExpired() {
  const now = Date.now();
  for (const [targetPhone, queue] of ephemeralQueue.entries()) {
    const remaining = queue.filter((item) => item.expiresAt > now);
    if (remaining.length === 0) {
      ephemeralQueue.delete(targetPhone);
    } else if (remaining.length !== queue.length) {
      ephemeralQueue.set(targetPhone, remaining);
    }
  }
  for (const [phone, otp] of pendingOtps.entries()) {
    if (otp.expiresAt <= now) {
      pendingOtps.delete(phone);
    }
  }
}

setInterval(purgeExpired, 30_000);

function safeSend(ws: WebSocket, data: unknown) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  }
}

function buildPublicUser(phone: string) {
  const stored = usersDb.get(phone);
  const onlinePeer = peers.get(phone);
  return {
    phone,
    name: onlinePeer?.name || stored?.name || phone,
    avatarDataUrl: onlinePeer?.avatarDataUrl || stored?.avatarDataUrl || null,
    online: Boolean(onlinePeer),
  };
}

function getRelationship(requester: string, target: string): 'none' | 'friend' | 'outgoing_pending' | 'incoming_pending' {
  if (!requester || requester === target) return 'none';
  if (friendships.has(makePairKey(requester, target))) return 'friend';
  if (friendRequests.has(`${requester}->${target}`)) return 'outgoing_pending';
  if (friendRequests.has(`${target}->${requester}`)) return 'incoming_pending';
  return 'none';
}

function getFriendBundle(phone: string) {
  const friends: Array<ReturnType<typeof buildPublicUser>> = [];
  const incomingRequests: Array<ReturnType<typeof buildPublicUser> & { createdAt: number }> = [];
  const outgoingRequests: Array<ReturnType<typeof buildPublicUser> & { createdAt: number }> = [];

  for (const key of friendships) {
    const [a, b] = parsePairKey(key);
    if (a === phone) friends.push(buildPublicUser(b));
    else if (b === phone) friends.push(buildPublicUser(a));
  }

  for (const req of friendRequests.values()) {
    if (req.toPhone === phone) {
      incomingRequests.push({ ...buildPublicUser(req.fromPhone), createdAt: req.createdAt });
    } else if (req.fromPhone === phone) {
      outgoingRequests.push({ ...buildPublicUser(req.toPhone), createdAt: req.createdAt });
    }
  }

  return { friends, incomingRequests, outgoingRequests };
}

function broadcastPresence(phone: string, online: boolean, name?: string, avatarDataUrl?: string) {
  const msg = {
    type: 'presence-update',
    phone,
    online,
    name,
    avatarDataUrl,
    timestamp: Date.now(),
  };
  for (const peer of peers.values()) {
    if (peer.phone !== phone) {
      safeSend(peer.ws, msg);
    }
  }
}

async function addDirToZip(zipFolder: JSZip, dirPath: string) {
  const entries = await fs.promises.readdir(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      const subFolder = zipFolder.folder(entry.name);
      if (subFolder) {
        await addDirToZip(subFolder, fullPath);
      }
    } else if (entry.isFile()) {
      const content = await fs.promises.readFile(fullPath);
      zipFolder.file(entry.name, content);
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, activePeers: peers.size, registeredUsers: usersDb.size });
  });

  app.post('/api/auth/request-otp', (req, res) => {
    const phone = normalizePhone(String(req.body?.phone || ''));
    if (!phone || phone.length < 8) {
      res.status(400).json({ error: 'সঠিক মোবাইল নম্বর দিন' });
      return;
    }

    const code = String(Math.floor(100000 + Math.random() * 900000));
    pendingOtps.set(phone, {
      phone,
      code,
      expiresAt: Date.now() + OTP_TTL_MS,
    });

    res.json({
      ok: true,
      phone,
      freeOtp: code,
      expiresInSec: Math.floor(OTP_TTL_MS / 1000),
    });
  });

  app.post('/api/auth/verify-otp', (req, res) => {
    const phone = normalizePhone(String(req.body?.phone || ''));
    const code = String(req.body?.code || '').trim();
    const requestedName = String(req.body?.name || '').trim();

    if (!phone || !code) {
      res.status(400).json({ error: 'মোবাইল নম্বর ও OTP কোড দিন' });
      return;
    }

    const pending = pendingOtps.get(phone);
    if (!pending || pending.expiresAt <= Date.now() || pending.code !== code) {
      res.status(401).json({ error: 'OTP কোড সঠিক নয় বা মেয়াদ শেষ হয়েছে' });
      return;
    }

    pendingOtps.delete(phone);

    const existing = usersDb.get(phone);
    const user: StoredUser = existing
      ? {
          ...existing,
          name: requestedName || existing.name,
          updatedAt: Date.now(),
        }
      : {
          phone,
          name: requestedName || phone,
          updatedAt: Date.now(),
        };

    usersDb.set(phone, user);
    persistDb();

    res.json({ ok: true, user });
  });

  app.get('/api/users/lookup', (req, res) => {
    const phone = normalizePhone(String(req.query?.phone || ''));
    const requester = normalizePhone(String(req.query?.requester || ''));
    if (!phone || phone.length < 8) {
      res.status(400).json({ error: 'সঠিক মোবাইল নম্বর দিন' });
      return;
    }

    const user = usersDb.get(phone);
    const onlinePeer = peers.get(phone);
    if (user || onlinePeer) {
      res.json({
        found: true,
        user: {
          ...buildPublicUser(phone),
          relationship: getRelationship(requester, phone),
        },
      });
      return;
    }

    res.json({ found: false, phone });
  });

  app.get('/api/friends', (req, res) => {
    const phone = normalizePhone(String(req.query?.phone || ''));
    if (!phone) {
      res.status(400).json({ error: 'মোবাইল নম্বর প্রয়োজন' });
      return;
    }
    res.json(getFriendBundle(phone));
  });

  app.post('/api/friends/request', (req, res) => {
    const fromPhone = normalizePhone(String(req.body?.fromPhone || ''));
    const toPhone = normalizePhone(String(req.body?.toPhone || ''));

    if (!fromPhone || !toPhone || fromPhone === toPhone) {
      res.status(400).json({ error: 'সঠিক মোবাইল নম্বর দিন' });
      return;
    }
    if (!usersDb.has(toPhone) && !peers.has(toPhone)) {
      res.status(404).json({ error: 'এই মোবাইল নম্বরে কোনো MediRay অ্যাকাউন্ট নেই' });
      return;
    }

    const pairKey = makePairKey(fromPhone, toPhone);
    if (friendships.has(pairKey)) {
      res.json({ ok: true, status: 'friend', friend: buildPublicUser(toPhone) });
      return;
    }

    // If reverse request exists, auto-accept both!
    const reverseKey = `${toPhone}->${fromPhone}`;
    if (friendRequests.has(reverseKey)) {
      friendRequests.delete(reverseKey);
      friendships.add(pairKey);
      persistDb();

      const targetPeer = peers.get(toPhone);
      if (targetPeer) {
        safeSend(targetPeer.ws, {
          type: 'friend-accepted',
          friend: buildPublicUser(fromPhone),
        });
      }
      res.json({ ok: true, status: 'friend', friend: buildPublicUser(toPhone) });
      return;
    }

    const reqKey = `${fromPhone}->${toPhone}`;
    const record: FriendRequestRecord = {
      fromPhone,
      toPhone,
      createdAt: Date.now(),
    };
    friendRequests.set(reqKey, record);
    persistDb();

    const targetPeer = peers.get(toPhone);
    if (targetPeer) {
      safeSend(targetPeer.ws, {
        type: 'friend-request-received',
        from: { ...buildPublicUser(fromPhone), createdAt: record.createdAt },
      });
    }

    res.json({ ok: true, status: 'outgoing_pending', user: buildPublicUser(toPhone) });
  });

  app.post('/api/friends/accept', (req, res) => {
    const phone = normalizePhone(String(req.body?.phone || ''));
    const friendPhone = normalizePhone(String(req.body?.friendPhone || ''));
    if (!phone || !friendPhone) {
      res.status(400).json({ error: 'তথ্য অসম্পূর্ণ' });
      return;
    }

    friendRequests.delete(`${friendPhone}->${phone}`);
    friendRequests.delete(`${phone}->${friendPhone}`);
    friendships.add(makePairKey(phone, friendPhone));
    persistDb();

    const requesterPeer = peers.get(friendPhone);
    if (requesterPeer) {
      safeSend(requesterPeer.ws, {
        type: 'friend-accepted',
        friend: buildPublicUser(phone),
      });
    }

    res.json({ ok: true, friend: buildPublicUser(friendPhone) });
  });

  app.post('/api/friends/decline', (req, res) => {
    const phone = normalizePhone(String(req.body?.phone || ''));
    const friendPhone = normalizePhone(String(req.body?.friendPhone || ''));
    friendRequests.delete(`${friendPhone}->${phone}`);
    friendRequests.delete(`${phone}->${friendPhone}`);
    persistDb();
    res.json({ ok: true });
  });

  app.get('/api/android-files', async (_req, res) => {
    const androidDir = path.join(__dirname, 'android-project');
    if (!fs.existsSync(androidDir)) {
      res.status(404).json({ error: 'Android project directory not found' });
      return;
    }
    const files: string[] = [];
    async function walk(dir: string, prefix: string) {
      const entries = await fs.promises.readdir(dir, { withFileTypes: true });
      for (const entry of entries) {
        const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
        if (entry.isDirectory()) {
          await walk(path.join(dir, entry.name), rel);
        } else {
          files.push(rel);
        }
      }
    }
    await walk(androidDir, '');
    res.json({ files: files.sort() });
  });

  app.get('/api/android-project.zip', async (_req, res) => {
    const androidDir = path.join(__dirname, 'android-project');
    if (!fs.existsSync(androidDir)) {
      res.status(404).json({ error: 'Android project not found' });
      return;
    }
    try {
      const zip = new JSZip();
      const rootFolder = zip.folder('MediRay-Android');
      if (rootFolder) {
        await addDirToZip(rootFolder, androidDir);
      }
      const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="MediRay-Android-Kotlin-Project.zip"');
      res.send(buffer);
    } catch (err) {
      console.error('Failed to zip android project:', err);
      res.status(500).json({ error: 'Failed to package Android project' });
    }
  });

  const APK_DIR = path.join(__dirname, 'public', 'downloads');
  const APK_FILENAME = 'MediRay-v1.0.0-release.apk';
  const APK_FILE_PATH = path.join(APK_DIR, APK_FILENAME);

  app.get('/api/apk-info', async (_req, res) => {
    try {
      const exists = fs.existsSync(APK_FILE_PATH);
      if (!exists) {
        res.json({
          available: false,
          appName: 'MediRay',
          packageName: 'com.mediray.app',
          versionName: '1.0.0',
          versionCode: 1,
          fileName: APK_FILENAME,
          sizeBytes: 0,
          sha256: '',
          updatedAt: null,
          downloadUrl: '/api/download-apk',
        });
        return;
      }
      const stat = await fs.promises.stat(APK_FILE_PATH);
      const buf = await fs.promises.readFile(APK_FILE_PATH);
      const sha256 = crypto.createHash('sha256').update(buf).digest('hex');
      res.json({
        available: true,
        appName: 'MediRay',
        packageName: 'com.mediray.app',
        versionName: '1.0.0',
        versionCode: 1,
        fileName: APK_FILENAME,
        sizeBytes: stat.size,
        sha256,
        updatedAt: stat.mtimeMs,
        downloadUrl: '/api/download-apk',
      });
    } catch {
      res.status(500).json({ error: 'Failed to inspect APK' });
    }
  });

  app.get('/api/download-apk', (_req, res) => {
    if (!fs.existsSync(APK_FILE_PATH)) {
      res.status(404).json({ error: 'Release APK এখনো তৈরি করা হয়নি' });
      return;
    }
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', `attachment; filename="${APK_FILENAME}"`);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.sendFile(APK_FILE_PATH);
  });

  app.post('/api/admin/build-apk', (_req, res) => {
    const androidDir = path.join(__dirname, 'android-project');
    const gradlewPath = path.join(androidDir, 'gradlew');
    const gradleBin = fs.existsSync(gradlewPath)
      ? './gradlew'
      : fs.existsSync('/opt/gradle/gradle-8.7/bin/gradle')
      ? '/opt/gradle/gradle-8.7/bin/gradle'
      : 'gradle';

    const env = {
      ...process.env,
      ANDROID_HOME: process.env.ANDROID_HOME || '/opt/android-sdk',
      ANDROID_SDK_ROOT: process.env.ANDROID_SDK_ROOT || '/opt/android-sdk',
      JAVA_HOME: process.env.JAVA_HOME || '/usr/lib/jvm/java-17-openjdk-amd64',
    };

    exec(
      `${gradleBin} assembleRelease --no-daemon`,
      { cwd: androidDir, env, timeout: 10 * 60 * 1000, maxBuffer: 10 * 1024 * 1024 },
      async (err, _stdout, stderr) => {
        if (err) {
          res.status(500).json({ error: stderr?.slice(-400) || err.message || 'APK build failed' });
          return;
        }
        const builtApk = path.join(androidDir, 'app', 'build', 'outputs', 'apk', 'release', 'app-release.apk');
        if (!fs.existsSync(builtApk)) {
          res.status(500).json({ error: 'Built APK output not found' });
          return;
        }
        await fs.promises.mkdir(APK_DIR, { recursive: true });
        await fs.promises.copyFile(builtApk, APK_FILE_PATH);
        res.json({ ok: true, downloadUrl: '/api/download-apk' });
      }
    );
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    let registeredPhone: string | null = null;

    ws.on('message', (raw) => {
      try {
        const data = JSON.parse(raw.toString());
        const type = data?.type;

        if (type === 'register' && typeof data.phone === 'string') {
          const phone = normalizePhone(data.phone);
          if (!phone) return;

          registeredPhone = phone;
          const stored = usersDb.get(phone);
          const name =
            typeof data.name === 'string' && data.name.trim()
              ? data.name.trim()
              : stored?.name || phone;
          const avatarDataUrl =
            typeof data.avatarDataUrl === 'string'
              ? data.avatarDataUrl
              : stored?.avatarDataUrl;

          peers.set(phone, {
            ws,
            phone,
            name,
            avatarDataUrl,
            connectedAt: Date.now(),
          });

          usersDb.set(phone, {
            phone,
            name,
            avatarDataUrl,
            updatedAt: Date.now(),
          });
          persistDb();

          const bundle = getFriendBundle(phone);
          safeSend(ws, {
            type: 'registered',
            phone,
            serverTime: Date.now(),
            ...bundle,
          });

          broadcastPresence(phone, true, name, avatarDataUrl);

          purgeExpired();
          const pending = ephemeralQueue.get(phone);
          if (pending && pending.length > 0) {
            for (const pkt of pending) {
              safeSend(ws, {
                type: 'relay-message',
                from: pkt.from,
                payload: pkt.payload,
              });
            }
            ephemeralQueue.delete(phone);
          }
          return;
        }

        if (type === 'lookup-phone' && typeof data.targetPhone === 'string') {
          const targetPhone = normalizePhone(data.targetPhone);
          const peer = peers.get(targetPhone);
          const stored = usersDb.get(targetPhone);
          if (peer || stored) {
            safeSend(ws, {
              type: 'user-found',
              user: {
                ...buildPublicUser(targetPhone),
                relationship: getRelationship(registeredPhone || '', targetPhone),
              },
            });
          } else {
            safeSend(ws, { type: 'user-not-found', targetPhone });
          }
          return;
        }

        if (type === 'check-presence' && Array.isArray(data.phones)) {
          const online: Record<string, { online: boolean; name?: string; avatarDataUrl?: string | null }> = {};
          for (const rawPhone of data.phones) {
            if (typeof rawPhone === 'string') {
              const p = normalizePhone(rawPhone);
              const u = buildPublicUser(p);
              online[p] = { online: u.online, name: u.name, avatarDataUrl: u.avatarDataUrl };
            }
          }
          safeSend(ws, { type: 'presence-state', online });
          return;
        }

        if ((type === 'rtc-offer' || type === 'rtc-answer' || type === 'rtc-ice') && typeof data.to === 'string') {
          const targetPhone = normalizePhone(data.to);
          const target = peers.get(targetPhone);
          if (target) {
            safeSend(target.ws, {
              ...data,
              from: registeredPhone || data.from,
            });
          }
          return;
        }

        if ((type === 'msg-ack' || type === 'msg-read') && typeof data.to === 'string') {
          const targetPhone = normalizePhone(data.to);
          const target = peers.get(targetPhone);
          if (target) {
            safeSend(target.ws, {
              type,
              from: registeredPhone,
              messageIds: Array.isArray(data.messageIds) ? data.messageIds : [],
            });
          }
          return;
        }

        if (type === 'relay-message' && typeof data.to === 'string' && data.payload) {
          const fromPhone = registeredPhone || normalizePhone(String(data.from || ''));
          const targetPhone = normalizePhone(data.to);
          const messageId = typeof data.payload.id === 'string' ? data.payload.id : '';
          const target = peers.get(targetPhone);

          if (target) {
            safeSend(target.ws, {
              type: 'relay-message',
              from: fromPhone,
              payload: data.payload,
            });
            if (messageId) {
              safeSend(ws, { type: 'relay-ack', messageId, deliveredNow: true });
            }
          } else {
            const now = Date.now();
            const list = ephemeralQueue.get(targetPhone) || [];
            list.push({
              id: messageId || `${now}-${Math.random()}`,
              to: targetPhone,
              from: fromPhone,
              payload: data.payload,
              expiresAt: typeof data.payload.expiresAt === 'number' ? data.payload.expiresAt : now + MESSAGE_TTL_MS,
            });
            ephemeralQueue.set(targetPhone, list);
            if (messageId) {
              safeSend(ws, { type: 'relay-ack', messageId, deliveredNow: false });
            }
          }
        }
      } catch (err) {
        console.error('WebSocket message error:', err);
      }
    });

    ws.on('close', () => {
      if (registeredPhone) {
        const current = peers.get(registeredPhone);
        if (current && current.ws === ws) {
          peers.delete(registeredPhone);
          broadcastPresence(registeredPhone, false);
        }
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`MediRay server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
